import java.util.Scanner;

class equal
{
public static void main(String args[])
{

	String a,b;
	Scanner s=new Scanner(System.in);
	System.out.println("Enter first string ");
	a=s.nextLine();

	System.out.println("Enter second string ");
        b=s.nextLine();


	if(a.equals(b))
	{
		System.out.println("equal");
	}
	else
	{
		System.out.println("not equal");
	}


	if(a.equalsIgnoreCase(b))
        {
                System.out.println("equal");
        }
        else
        {
                System.out.println("not equal");
        }
}
}

