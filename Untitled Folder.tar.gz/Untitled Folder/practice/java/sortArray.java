import java.util.Arrays;
import java.util.Collections;
class sortArray
{
	public static void main(String args[])
	{
		Integer[] arr={5,3,8,7,1,9};

		Arrays.sort(arr,Collections.reverseOrder());
		System.out.printf("Ans:%s",Arrays.toString(arr));
	}
}
