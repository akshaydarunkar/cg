import java.util.Scanner;
class demo
{
public static void main(String args[])
{
	String s;
	Scanner obs=new Scanner(System.in);
	System.out.println("enter string");
	s=obs.nextLine();
	System.out.println("you entered string "+s);
}
}
