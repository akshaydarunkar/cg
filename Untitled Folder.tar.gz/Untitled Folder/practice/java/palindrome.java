class palindrome
{
public static void main(String args[])
{
	String str="madam";
	String rev="";

	int l=str.length();

	for(int i=l-1;i>=0;i--)
		rev+=str.charAt(i);

	if(str.equals(rev))
	
		System.out.println(str+ "palindrom");
	else
		System.out.println(str+ "not palindrom");

}
}
