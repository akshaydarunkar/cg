class trim
{
public static void main(String args[])
{
	String s="  akshay  ";
	System.out.println(s.trim());
}
}
