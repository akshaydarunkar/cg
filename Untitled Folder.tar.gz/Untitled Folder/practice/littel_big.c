#include<stdio.h>

int main()
{
	int i;
	char *c=(char*)&i;
	
	if(*c)
		printf("littel endian");
	else
		printf("big endian");
return 0;
}
	
