#include<stdio.h>
#include<stdlib.h>

int large(int arr[],int n)
{
	int start=0,end=0,i;
	
	for(i=0;i<n;i++)
	{
		end+=arr[i];
		if(start<end)
			start=end;
		if(end<0)
			end=0;
	}
	return start;
}

int main()
{
	int arr[]={-2,-3,4,-1,-2,1,5,-3};
	int n=sizeof(arr)/sizeof(arr[0]);
	int max=large(arr,n);
	printf("%d ",max);
	return 0;
}


