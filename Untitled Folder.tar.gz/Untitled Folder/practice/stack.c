#include<stdio.h>
#include<stdlib.h>

struct Arraystack
{
	int top;
	int cap;
	int *array;
};

struct Arraystack *create(int data)
{
	struct Arraystack *s=(struct Arraystack*)malloc(sizeof(struct Arraystack));
	s->cap=data;
	s->top=-1;
	s->array=malloc(sizeof(int)*data);
	return(s);
}

int full(struct Arraystack *s)
{
	if(s->top == s->cap-1)
	{
		return(1);
	}
	else
		return(0);
}

int empty(struct Arraystack *s)
{
	if(s->top == -1)
	{
		return(1);
	}
	else
		return(0);
}

void push(struct Arraystack *s,int data)
{
	if(!full(s))
	{
		s->top++;
		s->array[s->top]=data;
	}
		printf("\npushed data");
}

int pop(struct Arraystack *s)
{
	if(!empty(s))
	{
		int temp=s->array[s->top];
			s->top--;
			return temp;
	}
		return -1;
}
void display(struct Arraystack *s)
{
	if(s->top==-1)
	{
		printf("\nstack empty");
	}
	else
	{
		for(int i=s->top;i>=0;i--)
		{
			printf("\nstack =%d\n",s->array[i]);
		}
		printf("\n");
	}
}
int main()
{
	struct Arraystack *s=create(4);
	int choice,item;

	while(1)
	{
		printf("\n 1.push");
		printf("\n 2.pop");
		printf("\n 3.display");
		printf("\n 4.exit");

		printf("\nenter ur choice :");
		scanf("%d",&choice);
	
	
	switch(choice)
	{
		case 1:	
			printf("\nenter the push element :");
			scanf("%d",&item);
			push(s,item);
			break;

		case 2: 
			item=pop(s);
			if(item==-1)
				printf("\nempty");
			else
				printf("\npoped value %d",item);
				break;
		case 3:
			display(s);
			break;
		case 4:
			exit(0);
	}
}
}
