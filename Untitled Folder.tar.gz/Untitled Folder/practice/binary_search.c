#include<stdio.h>
#include<stdlib.h>

int binary(int arr[],int l,int n,int x)
{
	if(n>=l)
	{
		int mid = l+(n-l)/2;
		
		if(arr[mid]==x)
			return mid;
		
		if(arr[mid] > x)
			l=mid-1;
		else
			n=mid+1;
			
	}
	return -1;
}

int main()
{
	int result;
	int arr[]={2,3,4,10,40};
	
	int n=sizeof(arr)/sizeof(arr[0]);
	for(int i=0;i<n;i++)
	printf("%d ",arr[i]);
	int x;
	printf("\nenter search element\n");
	scanf("%d",&x);
	
	result=binary(arr,0,n-1,x);
	if(result==-1)
		printf("false\n");
	else
		printf("true\n");

	return 0;
}
