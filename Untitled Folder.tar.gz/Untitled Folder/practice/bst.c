#include<stdio.h>
#include<stdlib.h>

struct node
{
	int data;
	struct node *left;
	struct node *right;
};
typedef struct node *bst;

bst create(int data)
{
	bst rt=(bst)malloc(sizeof(struct node));
	rt->data=data;
	rt->left=NULL;
	rt->right=NULL;
	return(rt);
}

bst insert(bst rt,int value)
{
	if(rt==NULL)
	{
		rt=create(value);
	}
	else
	{
		if(rt->data > value)
		{
			if(rt->left==NULL)
			{
				rt->left=create(value);
			}
			else
			{
				insert(rt->left,value);
			}
		}
		else(rt->data < value);
		{
			if(rt->right==NULL)
			{
				rt->right=create(value);
			}
			else
			{
				insert(rt->right,value);
			}
		}

	}
}

int inorder(bst rt)
{
	if(rt==NULL)
	{
		return 0;
	}
	inorder(rt->left);
	printf("%d ",rt->data);
	inorder(rt->right);
}

int preorder(bst rt)
{
	if(rt==NULL)
	{
		return 0;
	}
	printf("%d ",rt->data);
	preorder(rt->left);
	preorder(rt->right);
}

int postorder(bst rt)
{
	if(rt==NULL)
	{
		return 0;
	}
	postorder(rt->left);
	postorder(rt->right);
	printf("%d ",rt->data);
}
	
int main()
{
	bst akshay=create(40);
	
	insert(akshay,20);
	insert(akshay,30);
	insert(akshay,40);
	insert(akshay,50);
	insert(akshay,60);
	insert(akshay,70);
	insert(akshay,80);
	printf("\ninorder\n");
	inorder(akshay);
	
	printf("\npreorder\n");
	preorder(akshay);
	printf("\npostorder\n");
	postorder(akshay);

	return 0;
}



		




