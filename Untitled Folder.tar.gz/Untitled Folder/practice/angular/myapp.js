var app=angular.module("myapp",[]);

app.controller("myctrl",function($scope)
			{
			$scope.firstname="akshay";
			$scope.lastname="darunkar";
			});

