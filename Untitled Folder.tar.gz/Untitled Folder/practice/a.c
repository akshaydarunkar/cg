#include<stdio.h>

int main()
{
	char a[]="akshay",b[]="sagar";
	int i;
	
	printf("ans: %d",a[i+1]-'a');
}
