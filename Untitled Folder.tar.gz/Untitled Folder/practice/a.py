import math
__name__
print __name__

l=[8,2,4,1]
print l
i=0
while i<len(l):
	j=0
	while j<i:
		if l[i] < l[j]:
			temp=l[i]
			l[i]=l[j]
			l[j]=temp
		j=j+1
	i=i+1
print l	



			
