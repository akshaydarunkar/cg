#include<stdio.h>
#include<stdlib.h>

void modify(int arr[][],int R,int C)
{
	int i,j;
	int row[R];
	int col[C];
	printf("akshay");
	for(i=0;i<R;i++)
	{
		row[i]=0;
	}
	for(j=0;j<C;j++)
	{
		row[j]=0;
	}

	
	for(i=0;i<R;i++)
	{
		for(j=0;j<C;j++)
		{
			if(arr[i][j]==1)
			{
				row[i]=1;
				col[j]=1;
			}
		}
	}

	for(i=0;i<R;i++)
	{
		for(j=0;j<C;j++)
		{
			if(row[i]==1 || col[j]==1)
			{
				arr[i][j]=1;
			}
		}
	}
void print(int arr[R][C])
{
	
	for(int i=0;i<R;i++)
	{
		for(int j=0;j<C;j++)
		{
			printf("%d ",arr[i][j]);
		}
	}
}
}
int main()
{
	int arr[10][10],R,C;
	printf("enter row value:=");
	scanf("%d",&R);
	printf("enter colom value:=");
	scanf("%d",&C);

	printf("enter matrix value\n");
	for(int i=0;i<R;i++)
	{
		for(int j=0;j<C;j++)
		{
			scanf("%d",&arr[R][C]);
		}
	}
	
printf("modify matrix\n");
modify(arr[][],R,C);
return 0;
}
