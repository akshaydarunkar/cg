#include<stdio.h>
#include<stdlib.h>

struct node
{
	int data;
	struct node* next;
};

void push(struct node** node,int data)
{
	struct node* newnode=(struct node*)malloc(sizeof(struct node));
	newnode->data=data;
	newnode->next=(*node);
	(*node)=newnode;
}

void insertAfter(struct node* node,int data)
{
	if(node==NULL)
	{
		return 0;
	}

	struct node* newnode=(struct node*)malloc(sizeof(struct node));
	newnode->data=data;
	newnode->next=node->next;
	node->next=newnode;
}

void print(struct node* node)
{
	while(node!=NULL)
	{
		printf("%d->",node->data);
		node=node->next;
	}
}


int main()
{
	struct node* node=NULL;
	push(&node,1);
	push(&node,2);
	push(&node,3);
	push(&node,4);
	
	insertAfter(node->next->next,20);
	insertAfter(node->next,30);
	print(node);
	return 0;
}

	


