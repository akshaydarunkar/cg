def bubbleSort(arr):
	#n=len(arr)
	for i in range (len(arr)):
		for j in range(len(arr)-i-1):
			if arr[j]>arr[j+1]:
			
				temp=arr[j]
				arr[j]=arr[j+1]
				arr[j+1]=temp


arr=[4,2,7,9,12,1]
bubbleSort(arr)

for i in range(len(arr)):
	print arr[i]
