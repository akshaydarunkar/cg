#include<stdio.h>
#include<stdlib.h>

int selection(int arr[],int n)
{
	int i,j,min,temp;
	
	for(i=0;i<n-1;i++)
	{
		min=i;
		
		for(j=i+1;j<n;j++)
		
		if(arr[j]<arr[min])
			min=j;
		swap(&arr[min],&arr[i]);
	}
	int swap(int *x,int *y)
	{
			temp=x;
			x=y;
			y=temp;
	}
	return 0;
} 
int print(int arr[],int n)	
{
	for(int i=0;i<n;i++)
	{
		printf("%d",arr[i]);
	}
}
int main()
{
	int arr[]={5,2,1,6,7,9};
	int n=sizeof(arr)/sizeof(arr[0]);
	selection(arr,n);
	print(arr,n);
	return 0;
}

