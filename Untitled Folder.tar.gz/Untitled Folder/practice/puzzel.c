#include<stdio.h>

int main()
{
	int i;
	int c;
	i='c' + 'a';
	printf("%d",i);
	return 0;
}
