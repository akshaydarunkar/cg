#include<stdio.h>
#include<stdlib.h>
#include<string.h>

int palindrome(char str[])
{
	int l=0;
	int h=strlen(str)-1;

	while(l<h)
	{
		if(str[l++]!=str[h--])
		{
			printf("%s not palindrome\n",str);
			return 0;
		}
	}
	printf("%s palindrome\n",str);

return 0;
}

int main()
{
	palindrome("aaaabbaaaa");
	return 0;
}

