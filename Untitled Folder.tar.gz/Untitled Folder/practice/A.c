#include<stdio.h>
#include<string.h>

int main()
{
	char str='a';
	
	printf("%d",str);
}
