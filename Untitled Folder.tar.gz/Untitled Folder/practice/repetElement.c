#include<stdio.h>
#include<stdlib.h>

int main()
{
	int i,n,frequncy[9],k,flag=0,temp;
	printf("enter no:\n");
	scanf("%d",&n);
	temp=n;
	for(i=0;i<10;i++)
	{
		frequncy[i]=0;
	}

	while(n>0)
	{
		k=n%10;
		frequncy[k]++;
		n/=10;
	}
	
	for(i=0;i<10;i++)
	{
		if(frequncy[i]>1)
		{
			flag=1;
			printf("%d--->repeated %d times\n",i,frequncy[i]);
		}
		
	}

	if(flag==0)
	{
		printf("not repeated\n");
	}
	else
	{
		printf("repeated element here^\n");
	}
}
		
