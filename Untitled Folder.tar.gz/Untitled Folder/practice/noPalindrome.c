#include<stdio.h>
#include<stdlib.h>

int main()
{
	int r=0,temp,n,x;
	printf("enter no:\n");
	scanf("%d",&n);
	temp=n;
	while(n>0)
	{
		x=n%10;
		r=r*10+x;
		n/=10;
	}
	printf("%d %d",temp,r);

}
		
