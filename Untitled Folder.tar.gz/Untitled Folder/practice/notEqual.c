#include<stdio.h>
#include<stdlib.h>

int main()
{
	int a=10,b=20;
	
	while(a!=b)
	{
		printf("true\n");
		break;
	}
	printf("false\n");
}

