#include<stdio.h>
#include<string.h>

int main()
{
	int i,fact=1,n;
	char arr[50];

	printf("enter no:");
	scanf("%d",&n);

	for(i=1;i<=n;i++)
	{
		
		
			fact=fact*i;
		
	}

	printf("%d facroreal is %d",n,fact);
}
