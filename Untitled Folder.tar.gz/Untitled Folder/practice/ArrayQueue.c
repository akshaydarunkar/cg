#include<stdio.h>
#include<stdlib.h>

struct ArrayQueue
{
	int front,rear,size;
	int cap;
	int *array;
};

struct ArrayQueue *create(int cap)
{
	struct ArrayQueue *q=(struct ArrayQueue*)malloc(sizeof(struct ArrayQueue));
	q->cap=cap;
	q->front=0;
	q->rear=cap-1;
	q->array=malloc(sizeof(int)*cap);
	return(q);
}

int full(struct ArrayQueue *q)
{
	return (q->size==q->cap);
}

int empty(struct ArrayQueue *q)
{
	return (q->size==0);
}

void enqueue(struct ArrayQueue *q,int data)
{
	if(full(q))
	{
		return;
	}
	
	q->rear=(q->rear+1)%q->cap;
	q->array[q->rear]=data;
	q->size=q->size+1;
	printf("\nenqueue=%d\n",data);
}
int dequeue(struct ArrayQueue *q)
{
	if(empty(q))
	{
		return 0;
	}

	int data=q->array[q->front];
	q->front=(q->front+1)%q->cap;
	q->size=q->size-1;
		return data;
}
int front(struct ArrayQueue *q)
{
	if(empty(q))
		return 0;
	return q->array[q->front];
}
		
int rear(struct ArrayQueue *q)
{
	if(full(q))
		return 0;
	return q->array[q->rear];
}
		
int main()
{
	struct ArrayQueue *q=create(5);
	
	enqueue(q,10);
	enqueue(q,20);
	enqueue(q,30);

	printf("\ndequeue=%d",dequeue(q));
	printf("\nfront=%d",front(q));
	printf("\nrear=%d\n",rear(q));

	return(0);
}
		
