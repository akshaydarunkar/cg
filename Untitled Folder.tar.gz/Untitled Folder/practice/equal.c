#include<stdio.h>
#include<stdlib.h>

struct node
{
	int data;
	struct node *left;
	struct node *right;
	struct node* next;
};

typedef struct node *bst;

bst create(int data)
{
	bst rt=(bst)malloc(sizeof(struct node));
	
	rt->data=data;	
	rt->left=NULL;
	rt->right=NULL;
	return(rt);
}

int equal(bst a,bst b)
{
	while(a!=NULL && b!=NULL)
	{
		if(a->data!=b->data)
			return 0;
		
		a=a->next;
		b=b->next;
		
	}
	return(a==NULL && b==NULL);
}

int main()
{
	bst a=create(80);
	a->left=create(30);
	a->right=create(60);
	a->left->right=create(200);

	bst b=create(50);
	b->left=create(20);
	b->right=create(60);
	b->left->left=create(100);
	
	equal(a,b)?printf("equal"):printf("notequal");	
	return 0;
}



