str1="123"
print str1.atoi()

