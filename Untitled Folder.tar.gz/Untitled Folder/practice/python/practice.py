f=open("myfile.txt","w")
f.write("aaaaaaaaaaaaaa")
