from __future__ import print_function

class Solution(object):
    def longestCommonPrefix(self, strs):
        
        if not strs:
            return ""

        for i in xrange(len(strs[0])):
            for string in strs[1:]:
                if i >= len(string) or string[i] != strs[0][i]:
                    return strs[0][:i]
        return strs[0]


if __name__ == "__main__":
	print(Solution().longestCommonPrefix(["hello", "heaven", "heavy"]))
