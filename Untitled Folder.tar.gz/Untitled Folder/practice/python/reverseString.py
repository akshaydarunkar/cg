s="akshay"

def reverse(s):
	s=s[::-1]
	return s

print (reverse(s))


print s.split()
