n="1010"
n1="1010"

a=bin(int(n,2)+int(n1,2))
print "addition",a
