#include<stdio.h>
#include<stdlib.h>

struct Node
{
	int data;
	struct Node* next;
};

struct Node *newnode(int data)
{
	struct Node* node=(struct Node*)malloc(sizeof(struct Node));
	node->data=data;
	node->next=NULL;
	return node;
}

struct Node *merge(struct Node *h1,struct Node *h2)
{
	if(!h1)
		return h2;
	if(!h2)
		return h1;
	if(h1->data < h2->data)
	{
		h1->next=merge(h1->next,h2);
			return h1;
	}
	else
	{
		h2->next=merge(h1,h2->next);
			return h2;
	}
	
}	
void print(struct Node *node)
{
	while(node!=NULL)
	{
		printf("%d ",node->data);
		node=node->next;
	}
	
}
int main()
{
	struct Node *head1=newnode(5);
	head1->next=newnode(7);
	head1->next->next=newnode(9);
	
	struct Node *head2=newnode(4);
	head2->next=newnode(6);
	head2->next->next=newnode(8);
	
	struct Node *mergelist=merge(head1,head2);

	print(mergelist);
	return 0;
}

