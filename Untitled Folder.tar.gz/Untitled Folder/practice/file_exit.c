#include<stdio.h>

int main()
{
	FILE *file;
	file=fopen("a.c","r");

	if(file)
	{
		fclose(file);
		printf("exit");
	}
	else
	{
		printf("not");
	}
}
