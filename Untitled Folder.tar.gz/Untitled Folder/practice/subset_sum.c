#include<stdio.h>
#include<stdlib.h>

 subset(int arr[],int n,int sum)
{
	int i;
	if(sum==0)
		return true;
	if(n==0 && sum!=0)
		return false;
	if(arr[n-1]>sum)
		return subset(arr,n-1,sum);
	return subset(arr,n-1,sum) || subset(arr,n-1,sum-arr[n-1]);
}

int main()
{
	int arr[]={2,4,5,6,7,1};
	int n=6;
	int sum=9;

	if(subset(arr,n,sum)==true)
		printf("yes");
	else
		printf("No");

	return 0;
}


