#include<stdio.h>
#include<string.h>
#include<stdlib.h>

int main()
{
	int i,j,n;
	char str[50][50],s[50];

	printf("enter no: ");
	scanf("%d",&n);
	
	printf("enter word:\n");
	
	for(i=0;i<n;i++)
	{
		scanf("%s",str[i]);
	}

	
	for(i=0;i<n;i++)
	{
		for(j=i+1;j<n;j++)
		{
			if(strcmp(str[i],str[j])>1)
			{
				strcpy(s,str[i]);
				strcpy(str[i],str[j]);
				strcpy(str[j],s);
			}
		}
	}

	printf("\nsorted list:\n");
	
	for(i=0;i<n;i++)
	{
		printf("%s\n",str[i]);
	}
}
