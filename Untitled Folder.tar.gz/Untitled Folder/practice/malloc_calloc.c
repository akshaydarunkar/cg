#include<stdio.h>
#include<stdlib.h>

void main()
{
int arr[10]={1,2,3,4,5};

int *p=(int*)malloc(sizeof(int)); //Dynamic memory allocation

int *q=(int *)calloc(5,sizeof(int)); //Dynamic memory allocation

printf("Sizeof array by static and dynamic allocation\n");

printf("%d\n%d\n",sizeof(p),sizeof(q));
}

