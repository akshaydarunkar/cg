#include<stdio.h>

int main()
{

int k=fun(3);
printf("%d",k);
}

int fun(int a)
{

if(a==1)
	return(a);
int s=a+fun(a-1);
return(s);
}

