#include<stdio.h>
#include<string.h>
#include<stdlib.h>

int main()
{
	char s[100];
	printf("enter string\n");
	scanf("%s",&s);
	int i,count=0;
	
	for(i=0;s[i]!='\0';i++)
	{
		if(s[i]=='A' || s[i]=='E' ||s[i]=='I' ||s[i]=='O' ||s[i]=='U' ||
	   	   s[i]=='a' || s[i]=='e' ||s[i]=='i' ||s[i]=='o' ||s[i]=='u')
		{
			
			count++;
		}	
	}


	if(count==0)
	{
		printf("not\n");
	}
	else
	{
		printf("count:%d\n",count);
		
	}
}
