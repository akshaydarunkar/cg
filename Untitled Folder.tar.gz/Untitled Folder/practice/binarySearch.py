
def binary(arr,l,n,s):
	while l<=n:
		mid=l+(n-l)/2

		if (arr[mid]==s):
			return mid
		elif (arr[mid]<s):
			l=mid+1
		else:
			n=mid-1
	
	return -1

arr=[1,2,3,4,5,6,7,8]
s=2

result=binary(arr,0,len(arr)-1,s)
if result !=-1:
	print "true"
else:
	print "false"

