#include<stdio.h>

int main()
{
	int x=99,y=100;
	y=(x*y)/(x=y);
	printf("%d and %d",x,y);
	return 0;
}
