#include<stdio.h>
#include<stdlib.h>
#include<string.h>

int search(char *ptr,char *txt)
{
	int i=0,j;
	int m=strlen(ptr);
	int n=strlen(txt);
	
	for(i=0;i<n-m;i++)
	{
		for(j=0;j<m;j++)
		
			if(txt[i+j]!=ptr[j])
				break;
			if(j==m)
			
				printf("yes %d \n",i);
			
		
	}
}


int main()
{
	char txt[]="AABBHNSGBSKSSYSHSBN";
	char ptr[]="S";
	search(ptr,txt);
	return 0;
}

