#include<stdio.h>
#include<stdlib.h>

int main()
{
	char str[]="12345";
	//int n=atoi(str);
	printf("and=%d",str);
}

