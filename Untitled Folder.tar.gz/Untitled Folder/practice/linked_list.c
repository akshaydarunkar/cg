#include<stdio.h>
#include<stdlib.h>

struct node
{
	int data;
	struct node *next;
};
typedef struct node *list;

list create(int data)
{
	list ls=(list)malloc(sizeof(struct node));
	ls->data=data;
	ls->next=NULL;
	return(ls);
}

list insert(int data,list ls)
{
	if(ls==NULL)
	{
		ls=create(data);
	}
	else
	{
		ls->next=insert(data,ls->next);
			return(ls);
	}
}

void print(list ls)
{
	if(ls==NULL)
	{
		printf("NULL");
			return;
	}
	else
	{
		printf("%d->",ls->data);
		print(ls->next);
	}
}

list insertFirst(int data,list ls)
{
	list temp;

	if(ls==NULL)
	{
		ls=create(data);
	}
	else
	{
		temp=create(data);
		temp->next=ls;
		ls=temp;
		return(ls);
	}
}
int reverse(list ls)
{
	if(ls==NULL)
	{
		return(0);
	}
	else
	{
		reverse(ls->next);
		printf("%d->",ls->data);
		
	}
	
}
int count(list ls)
{
	if(ls==NULL)
	{
		return 0;
	}
	int len=0;
	while(ls!=NULL)
	{
		len++;
		ls=ls->next;
	}
	return len;
}	
int main()
{
	list akshay=create(50);
	insert(20,akshay);
	insert(30,akshay);
	print(akshay);
	akshay=insertFirst(100,akshay);
	printf("\n");
	print(akshay);
	printf("\n");
	reverse(akshay);
	printf("\nlength=%d\n",count(akshay));
	return 0;
}
	



	
