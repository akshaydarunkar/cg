
def subsequnce(s,s1,m,n):
	i=0
	j=0
	while i<m and j<n:
		if(s1[i]==s[j]):
			i=i+1
		j=j+1
	return i==m









s="aksha"
s1="akshay"

m=len(s)
n=len(s1)

if subsequnce(s,s1,m,n):
	print True
else:
	print False
