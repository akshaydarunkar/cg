#include<stdio.h>
int search(int arr[],int n,int x)
{
	int i;
	for(i=0;i<n;i++)
		if(arr[i]==x)
			return i;
		return -1;
	
}

int main()
{
	int x;
int arr[]={3,5,7,9,1,6};
int n=sizeof(arr)/sizeof(arr[0]);

printf("enter search element");
scanf("%d",&x);
printf("%d index\n",search(arr,n,x));
return 0;
}


