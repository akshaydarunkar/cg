#include<stdio.h>
#include<stdlib.h>

struct ArrayStack
{
	int top;
	int capacity;
	int *array;
};

struct ArrayStack* create(int cap)
{
	struct ArrayStack *s;
	s=malloc(sizeof(struct ArrayStack));
	s->capacity=cap;
	s->top=-1;
	s->array=malloc(sizeof(int)*s->capacity);
	return(s);
}

int full(struct ArrayStack *s)
{
	if(s->top==s->capacity-1)
		return(1);
	else
		return(0);
}
int empty(struct ArrayStack *s)
{
	if(s->top==-1)
		return(1);
	else
		return(0);
}

void push(struct ArrayStack *s,int data)
{
	if(!full(s))
	{
		s->top++;
		s->array[s->top]=data;
	}
	printf("pushed value:%d",data);
}

int pop(struct ArrayStack *s)
{
	int temp;
	if(!empty(s))
	{
	temp=s->array[s->top];
	s->top--;
	return(temp);
	}
	return(-1);
}
void display(struct ArrayStack *s)
{
	if(s->top==-1)
	{
		printf("stack is empty");
			return;
	}
	else
	{
		printf("\nU Entered Elements:\n");
		for(int i=s->top;i>=0;i--)
		{
			printf("%d\n",s->array[i]);	
		}
	}
	printf("\n");
}
int istop(struct ArrayStack *s)
{
	
	return(s->array[s->top]);
	
}


void main()
{
	int choice,n;
	struct ArrayStack *stack=create(5);
	
	while(1)
	{
	printf("\n 1: push");
	printf("\n 2: pop");
	printf("\n 3: display");
	printf("\n 4: Top");
	printf("\n 6: exit");
		
	printf("\n enter your choice: ");
	scanf("%d",&choice);

	switch(choice)
	{
		case 1:
			printf("enter the value:");
			scanf("%d",&n);
			push(stack,n);
			break;
		
		case 2:
			n=pop(stack);
			if(n==-1)
				printf("\n Stack is empty");
			else
				printf("\n poped value %d",n);
			break;
	
		case 3:
			display(stack);
			break;
		case 4:
			printf("Top value:%d\n",istop(stack));
			break;
		
		case 6:
			exit(0);
	}
}
}
