s1=raw_input("enter 1st string:")
s2=raw_input("enter 2nd string:")

a=list(set(s1)-set(s2))
for i in a:
   print(i)
