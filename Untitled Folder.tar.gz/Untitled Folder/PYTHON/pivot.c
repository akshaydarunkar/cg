#include<stdio.h>
#include<string.h>
#include<stdlib.h>

int check(int i)
{
	if(i%2==0)
		return 0;
	else
		return 1;
}

char* fun(char str[])
{
	int len = strlen(str);
	char* final=(char *)malloc((len)*sizeof(char));
	int i,T,F,B;

	if (check(len)==1?(B=F=((len/2)-1)):(B=F=(len/2)));
	T=B;
	T++;
	B--;
	

	for(i=0;i<len;i++)
	{
		if(i==0)
		{
			final[T]=str[i];
		}
		if(check(i)==1)
		{
			final[F]=str[i];
			F++;
		}
		else
		{
			final[B]=str[i];
			B--;
		}
	}
	return final;
}
	int main()
	{
		char str[] = "shkaay";
		printf("FINAL STRING:%s\n",fun(str));
	}

