def search(ptr,txt):
	m=len(ptr)
	n=len(txt)
	for i in xrange(n-m+1):
		for j in xrange(m):
			if(txt[i+j]!=ptr[j]):
			   break
		if j==m-1:
			print "pattern  found at index" +str(i)	


txt="AABAAABAAAABBAA"
ptr="AABA"

search(ptr,txt)

