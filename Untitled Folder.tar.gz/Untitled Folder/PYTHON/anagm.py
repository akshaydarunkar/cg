s1=raw_input("enter 1st string:")
s2=raw_input("enter 2nd string:")

if (sorted(s1)==sorted(s2)):
   print "anagram"
else:
   print "not anagram"
