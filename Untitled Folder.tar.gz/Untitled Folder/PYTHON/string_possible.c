#include<stdio.h>
#include<stdlib.h>
#include<string.h>

int printpattern(char str[])
{
	int n=strlen(str);
	char buff[2*n];
	buff[0]=str[0];
	pattern(str,buff,1,1,n);
}

int pattern(char str[],char buff[],int i,int j,int n)
{
	if(i==n)
	{
		buff[j]='\0';
		printf("%s\n",buff);
		return 0;

	}

	buff[j]=buff[i];
	pattern(str,buff,i+1,j+1,n);

	buff[j]=' ';
	buff[j+1]=str[i];
	pattern(str,buff,i+1,j,n);
}

int main()
{
	char *str="ABC";
	printpattern(str);
	return 0;
}

