#!/usr/bin/python
import sys

#str = "a_b s_c d_c"
#for x in str:
#   print str
#########################################
#for x in xrange(10):
#   print x
#else:
#	print "final X=%d"%(x)

#########################################

#p = ['hey',5,4,2]
#for x in p:
#   print x
#########################################

#list_of_list=[1,2],[1,2,3]
#for list in list_of_list:
#   for x in list:
#      print x
########################################

#list = [1,2,3];
#print "list",list[0]
#####################################
"""
def myf():
   print ("akshay")
def arg(user):
  print (user)
def sum(a,b):
   print (a+b)

myf()
x=sum(1,2)
arg("darunkar")
print x
"""
########################################
"""n=[1,2,3,4,5,6]
print (len(n))
"""
########################################
"""n=[1,2,3]+[1,2]

print " ",n"""
#######################################
"""list=[1,2,3,4,5]
list.extend([6,7])
print list
"""
#######################################
#list=[1,2,3,4,5]
#list.append([6,7])
#print list
#######################################

#list=['a','b','c']
#list.extend(['d'])
#print list
#####################################
"""n=["a_s d_s v_f f_g"]
for element in n:
    w=element.split(" ")
    print (w)
for s in w:
    c=s.split(",")
    print (c)

for a in c:
    x=a.split("_")
    print (x)   
"""
#####################################
    
"""l = ['14,23,63\n','41,20,76\n','65,23,42\n']
for element in l:
    element.split(',')
    print element

"""
#############################################
"""
n=["a_b"]
for x in n:
    p=x.split("_")
    print (p)
"""
#########################################

"""a=10
b=20

if(a is not b):
   print a
else:
   print b
"""
###############################
"""var=100
if var==10:
   print "true"
   print var

elif var==50:
   print "true1"
   print var

elif var==100:
   print "true2"
   print var
"""
#################################
"""count =0

while(count < 9):
   print "count:",count
   count=count + 1
"""
###################################
"""
num = input("enter no:")
num1 = input("enter no:")
sum=num+num1
print sum
"""
#####################################
#test = raw_input("enter name:")
#print test

#########################################

#for letter in 'akshay':
#   print "current letter:->",letter
##########################################
#str="akshay"
#print "STRINF:",str.capitalize()
##########################################
#str="akshay"
#print "str:",str.capitalize()
#########################################

#str="akshay	darunkar	sss"
#print "Srting:",str.expandtabs(2)
######################################
#str = "THIS is string example....wow!!!";
#print str.isupper();
#########################################

#str = "this is string example....wow!!!";
#print str.upper();
#str = "THIS IS LOWER STRING!!!";
#print str.lower();
"""
##########################################


