from collections import defaultdict
a="7 0-1-2 0-3-2 1-2-3 2-4-3 3-4-5 4-5-6 5-6-2 6-7-1"
a=a.split()
print a
lst=[]
lst1=[]
lst2=[]
al=[]
path=[]
for i in range(1,len(a)):
	lst.append(a[i][0])
	lst1.append(a[i][2])
	lst2.append(a[i][4])
lst3=zip(lst1,lst2)
z=map(list,zip(lst,lst3))
print z
d=defaultdict(list)

for i,j in z:
	d[i].append(j)
print d
def all(x):
	ss=d[x]
	for i in range(len(ss)):
		al.append(ss[i][0])
	
def is_connected(x,y):
	ww=[]
	ss=d[x]
	print ss
	for i in range(len(ss)):
		al.append(ss[i][0])
	for j in range(len(al)):
		xl=all(al[j])

	if y in al:
		print 'True'
	else:
		print 'False'

def shortest_path(x,y,path=[]):
	path = path + list(x)
        if x == y:
            return path
        if not d.has_key(x):
            return None
        for j in d[x]:
            if j not in path:
                newpath = shortest_path(j, y, path)
                if newpath: return newpath
	
        return None	
x='0'
y='1'
is_connected(x,y)
s1=shortest_path(x,y)
print s1
