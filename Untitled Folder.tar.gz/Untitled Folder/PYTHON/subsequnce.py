def subsequnce(str1,str2,m,n):

   if m == 0:    
      return True
   if n == 0:    
      return False

   if str1[m-1] == str2[n-1]:
      return subsequnce(str1, str2, m-1, n-1)

   return subsequnce(str1, str2, m, n-1)

str1="pqr"
str2="akshay"

m=len(str1)
n=len(str2)

if subsequnce(str1, str2, m, n):
   print "y"
else:
   print "n"



