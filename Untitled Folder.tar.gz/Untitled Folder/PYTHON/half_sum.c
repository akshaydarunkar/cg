#include<stdio.h>
#include<stdlib.h>
#include<string.h>

int find(char *str)
{
	int n=strlen(str);
	int max=0;
	for(int i=0;i<n;i++)
	{
		for(int j=i+1;j<n;j+=2)
		{
			int length=j-i+1;
			int left=0,right=0;
			for(int k=0;k<length/2;k++)
			{
				left+=(str[i+k]-'0');
				right+=(str[i+k+length/2]-'0');
				printf("  left: %d\n",left);
				printf(" right: %d\n",right);
				printf("length:%d",length);
			}
			if(left==right && max<length)
				max=length;
		}
	}
	return max;
}

int main(void)
{

	char str[]="123123";

	printf("Length:%d\n",find(str));
	return 0;
}

