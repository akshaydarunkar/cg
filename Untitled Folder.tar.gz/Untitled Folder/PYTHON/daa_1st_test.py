l='a_b a_c b_d b_c a_k n_a d_g k_m g_c a_x'
l=l.split()
p='b'
def allchilds(list1,p,ch):
    for i in list1:
        if i[0]==p:
            ch.append(i)
            allchilds(list1,i[2],ch)
    return ch
def childs(list1,p,ch):
    for i in list1:
        if i[0]==p:
            ch.append(i)
    return ch

def ancesstor(l,p,h,b):
    a=allchilds(l,p,[])
    if b in a:
        print "Ancesstor"
    else:
        print "Not"
print allchilds(l,p,[])
print childs(l,p,[])
ancesstor(l,p,[],'b')
