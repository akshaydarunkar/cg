def find_child(z,root):
	a=[]
	for i in range(len(z)):
		if(z[i][0]==root):
			a.append(z[i][1])
	print a

def find_all_child(z,root,a):
	for i in range(len(z)):
		if(z[i][0]==root):
			a.append(z[i][1])
			find_all_child(z,z[i][1],a)
	return a

def find_ancestor(z,root,root1):
	x=find_all_child(z,root,[])
	if root1 in x:
		print "True"
	else:
		print "False"


s='a-b a-c b-d b-e a-f m-a'
l=s.split()
lst=[]
lst1=[]
for i in range(len(l)):
	lst.append(l[i][0])
	lst1.append(l[i][2])
z=map(list,zip(lst,lst1))
root='b'
root1='c'
#find_child(z,root)
#x=find_all_child(z,root,[])
#print x
find_ancestor(z,root,root1)

