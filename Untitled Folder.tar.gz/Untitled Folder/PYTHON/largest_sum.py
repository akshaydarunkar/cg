from sys import maxint

def maxSubArray(arr,n):
	start=0
	end=0
	for i in range(0,n):
		end=end+arr[i]
		if (start<end):
		   start=end
		
		if (end<0):
		   end=0
	return start


arr=[-2, -3, 4, -1, -2, 1, 5, -3]
n=len(arr)
print "sum:",maxSubArray(arr,n)

