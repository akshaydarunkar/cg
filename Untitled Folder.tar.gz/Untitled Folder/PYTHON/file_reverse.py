filename=input("enter filr name:")
for line in reversed(list(open(filename))):
   print(line.rstrip())

