s=raw_input("enter string:")
count=0
vowel=("aeiou")

for letter in s:
   
   if letter in vowel:
      print letter
      count+=1

print(count)
