from string import ascii_lowercase as asc_lower

def check(s):
   return set(asc_lower) - set(s.lower()) ==set([])
string =raw_input("enter string:")
if(check(string)==True):
   print "pangram"
else:
   print "not pangram"

