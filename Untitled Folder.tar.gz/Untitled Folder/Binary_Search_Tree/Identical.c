#include<stdio.h>
#include<stdlib.h>

struct node
{
	int data;
	struct node* next;
};

void push(struct node** node,int data)
{
	struct node* newnode=(struct node*)malloc(sizeof(struct node));
	newnode->data=data;
	newnode->next=(*node);
	(*node)=newnode;
}

int identical(struct node *a,struct node *b)
{
	while(a!=NULL && b!=NULL)
		{
		
		if(a->data!=b->data)
			return 0;
		a=a->next;
		b=b->next;
		}		
	return(a==NULL && b==NULL);
}


int main()
{

struct node* a=NULL;
struct node* b=NULL;

	push(&a,1);
	push(&a,2);
	push(&a,3);
	push(&b,1);
	push(&b,2);
	push(&b,3);

	identical(a,b)?printf("identical\n"):printf("not identical");
return 0;
}

