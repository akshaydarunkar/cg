#include<stdio.h>
#include<stdlib.h>

struct node
{
	int data;
	struct node* left;
	struct node* right;
};

struct node* create(int data)
{

	struct  node* node=(struct node*)malloc(sizeof(struct node));
	node->data=data;
	node->left=NULL;
	node->right=NULL;
	return(node);
}
int size(struct node* node)
{
	if(node==NULL)
		return 0;

	else
		return size(node->left)+ 1 +size(node->right);
}

int main()
{
	struct node* node=create(1);
	node->left=create(2);
	node->right=create(3);
	node->left->right=create(4);
	node->left->left=create(5);
	node->left->left->right=create(6);
	node->left->left->left=create(7);
	node->left->left->left->left=create(8);

	printf("Size:%d",size(node));
	return 0;
}

