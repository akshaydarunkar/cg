#include<stdio.h>
#include<stdlib.h>

struct node
{
	int data;
	struct node* left;
	struct node* right;
};

struct node* create(int data)
{
	struct node* node=(struct node*)malloc(sizeof(struct node));

	node->data=data;
	node->left=NULL;
	node->right=NULL;
	return(node);
}

int leafNode(struct node* node)
{
	if(node==NULL)
		return 0;
	if(node->left==NULL && node->right==NULL)
		return 1;
	else
		return leafNode(node->left)+
			leafNode(node->right);
}

int main()
{
	struct node *node=create(1);
	node->left=create(2);
	node->right=create(3);
	node->left->right=create(4);
	node->left->left=create(5);

	printf("\nleafNode:%d\n",leafNode(node));
	return 0;
}





