#include<stdio.h>
#include<stdlib.h>

struct node
{
	int data;
	struct node *left;
	struct node *right;
};

typedef struct node *BST;

BST create(int value)
{

	BST root=(BST)malloc(sizeof(struct node));

	root->data=value;
	root->right=NULL;
	root->left=NULL;
	return root;
}
BST insert(int value,BST rt)
{
	if(rt==NULL)
	{
		rt=create(value);
		return rt;
	}
	else
	{
		if(rt->data > value)
		{
			if(rt->left==NULL)
			{
				rt->left=create(value);
			}
			else
			{
				insert(value,rt->left);
			}
		}
		else
		{
		if(rt->data < value)
		{
			if(rt->right==NULL)
			{
				rt->right=create(value);
			}
			else
			{
				insert(value,rt->right);
			}
				return rt;
		}
	}
	
	}
	return rt;
	}

		     
		void inorder(BST rt)
		{
			if(rt==NULL)
			{
			return;
			}
			else
			{
			inorder(rt->left);
			printf("%d,",rt->data);
			inorder(rt->right);
			}
		}
			
		void preorder(BST rt)
		{
			if(rt==NULL)
			{
			return;
			}
			else
			{
			printf("%d,",rt->data);
			preorder(rt->left);
			preorder(rt->right);
			}
		}

		void postorder(BST rt)	
		{
			if(rt==NULL)
			{
			return ;
			}
			else
			{
			postorder(rt->left);
			postorder(rt->right);
			printf("%d,",rt->data);
			}
		}
		
			int main()
			{
				BST akshay=create(100);
			
				insert(50,akshay);
				insert(60,akshay);
				insert(70,akshay);
				insert(110,akshay);
				insert(120,akshay);
				insert(130,akshay);
			
				printf("inorder is:");
				inorder(akshay);
				printf("\npreorder is:");
				preorder(akshay);
				printf("\npostorder is:");
				postorder(akshay);
			}


