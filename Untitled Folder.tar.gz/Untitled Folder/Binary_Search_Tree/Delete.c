#include<stdio.h>
#include<stdlib.h>

struct node
{
	int data;
	struct node* left;
	struct node* right;
};


struct node* create(int data)
{
	struct node* node=(struct node*)malloc(sizeof(struct node));

	node->data=data;
	node->left=NULL;
	node->right=NULL;
	return(node);
}

void delete(struct node* node)
{
	if(node==NULL)
		return;
	delete(node->left);
	
	printf("\n Deleted node %d",node->data);
	free(node);
}
int main()
{
	struct node *root=create(1);
	root->left        =create(2);
	root->right       =create(3);
	root->left->left  =create(4);
	root->left->right =create(5);

	delete(root);
	root=NULL;
	printf("\n Tree Delete");
	return 0;
}
