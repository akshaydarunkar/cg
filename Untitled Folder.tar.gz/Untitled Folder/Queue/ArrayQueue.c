#include<stdio.h>
#include<stdlib.h>

struct ArryQ
{
	int front,rear,size;
	int capacity;
	int *array;
};

struct ArryQ* create(int cap)
{
	struct ArryQ *q=(struct ArryQ *)malloc(sizeof(struct ArryQ));
	q->capacity=cap;
	q->front=0;
	q->rear=q->capacity-1;
	q->array=(int *)malloc(sizeof(int)*q->capacity);
	return(q);
}

int isfull(struct ArryQ *q)
{
	return(q->front==q->capacity);
}

int isempty(struct ArryQ *q)
{
	return(q->capacity==0);
}

int enQueue(struct ArryQ *q, int item)
{
	if(isfull(q))
		return 0;
	q->rear=(q->rear+1)%q->capacity;
	q->array[q->rear]=item;
	q->size=q->size+1;
	printf("%d enQueue \n",item);
}

int deQueue(struct ArryQ *q)
{
	if(isempty(q))
		return 0;
	int item=q->array[q->front];
	q->front=(q->front+1)%q->capacity;
	q->size=q->size-1;
	return(item);
}

int isfront(struct ArryQ *q)
{
	if(isempty(q))
		return 0;
	return(q->array[q->front]);
}

int isrear(struct ArryQ *q)
{
	if(isempty(q))
		return 0;
	return(q->array[q->rear]);
}

int main()
{
	struct ArryQ *q=create(5);

	enQueue(q,10);
	enQueue(q,20);
	enQueue(q,30);

	printf("deQueue elmemt:%d \n",deQueue(q));

	printf("Front:%d \n",isfront(q));
	printf("rear: %d \n",isrear(q));
	return(0);
}

