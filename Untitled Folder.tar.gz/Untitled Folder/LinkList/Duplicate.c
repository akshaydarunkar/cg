#include<stdio.h>
#include<stdlib.h>

struct node
{
	int data;
	struct node* next;
};

void push(struct node** node,int data)
{
	struct node* newnode=(struct node*)malloc(sizeof(struct node));
	newnode->data=data;
	newnode->next=*node;
	*node=newnode;
}

void removeDuplicate(struct node* node)
{
	struct node* current=node;
	struct node* next_next;

	if(current == NULL)
		return;
	while(current->next!=NULL)
	{

		if(current->data==current->next->data)
		{
			next_next=current->next->next;
			free(current->next);
			current->next=next_next;
			
		}
		else
		{
			current=current->next;
		}
	}
}
void print(struct node* node)	
{
	while(node!=NULL)
	{
		printf("%d ",node->data);
		node=node->next;
	}
}

int main()
{
	struct node* node=NULL;
	
	push(&node,1);
	push(&node,2);
	push(&node,3);
	push(&node,3);
	push(&node,3);
	push(&node,4);
	printf("\ngiven list: ");
	print(node);

	removeDuplicate(node);
	printf("\n new list: ");
	print(node);
return 0;
}

