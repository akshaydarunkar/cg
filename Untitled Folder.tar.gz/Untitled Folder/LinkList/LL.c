#include<stdio.h>
#include<stdlib.h>

struct node
{
	int data;
	struct node *next;
};

typedef struct node *list;

list create(int value)
{
	list ls=(list)malloc(sizeof(struct node));

	ls->next=NULL;
	ls->data=value;
	return ls;
}

list insert(int data,list ls)
{
	if(ls==NULL)
	{
		ls=create(data);
	}
	else
	{
		ls->next=insert(data,ls->next);
		return ls;
	}
}

list insertfirst(int data,list ls)
{
	list temp;

	if(ls==NULL)
	{
		ls=create(data);
	}
	else
	{
		temp=create(data);
		temp->next=ls;
		ls=temp;
		return ls;	
	}

}
/*
list kthlocation(int data,list ls,int n)

{
	int size;
	printf("hello");
	if(ls==NULL)
	{
		ls=create(data);
	}
	else
	{
		ls=insertfirst(data,ls->next);
	}
	else if( n>size+1 || size+1 == n)
			return 1;
		
	}
	else
	{
		list temp;
		temp=create(data);

		list *cnt=ls;
		list *cnt1=ls->next;
		int count=1;

		cnt = ls->next;
		cnt1 =  ls->next;
		count++;


		temp->next=cnt1;

		return ls;
	}

}		



*/

list count(list ls)
{
	if(ls==NULL)
	{
		return 0;
	}
	else
	{
	
	list temp;
	temp = ls;

	int length=0;
		while(temp!=NULL)
		{
		length++;
		temp=temp->next;
		}
	printf("\ncount :%d",length);
	}
}




void print(list ls)
{

	if(ls==NULL)
	{
		printf("NULL");
		return;
	}
	else
	{
		printf("%d-->",ls->data);
		print(ls->next);
	}
}

list reverse(list ls)
{
	if(ls==NULL)
	{
		return 0;
	}
	else
	{

		reverse(ls->next);
		printf("%d \n",ls->data);
	}

}
int main()
{
	list akshay=create(10);

	insert(20,akshay);
	print(akshay);
	printf("\n");
	akshay=insertfirst(30,akshay);
	print(akshay);
	printf("\n");
//	akshay=kthlocation(15,akshay,2);
//	print(akshay);
//	printf("\n");
	reverse(akshay);
	count(akshay);
	printf("\n");
}
