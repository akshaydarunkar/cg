#include<stdio.h>
#include<stdlib.h>

struct Node
{
	int data;
	struct Node* next;
};

struct Node *newnode(int data)
{
	struct Node* node=(struct Node*)malloc(sizeof(struct Node));
	node->data=data;
	node->next=NULL;
	return(node);
}

struct Node *mergeList(struct Node *h1,struct Node *h2)
{
	if(!h1)
		return h2;
	if(!h2)
		return h1;
	if(h1->data < h2->data)
	{
		h1->next=mergeList(h1->next,h2);
		return h1;
	}
	else
	{
		h2->next=mergeList(h1,h2->next);
		return h2;
	}
}
void print(struct Node *node)
{
	while(node!=NULL)
	{
		printf("%d ",node->data);
		node=node->next;
	}
}
	

int main()
{
struct Node *node1=newnode(5);
node1->next=newnode(7);
node1->next->next=newnode(9);

struct Node *node2=newnode(4);
node2->next=newnode(6);
node2->next->next=newnode(8);
struct Node *merge=mergeList(node1,node2);

print(merge);
return 0;
}
