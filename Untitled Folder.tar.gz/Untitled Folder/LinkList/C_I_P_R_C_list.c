#include<stdio.h>
#include<stdlib.h>

struct node
{
	int data;
	struct node *next;
};

typedef struct node *list;

list create(int value)
{

	list ls=(list)malloc(sizeof(struct node));

	ls->data=value;
	ls->next=NULL;

	return ls;
}

list insert(int data,list ls)
{
	if(ls==NULL)
	{
		ls=create(data);
	}
	else
	{
		ls->next=insert(data,ls->next);
		return ls;
	}
}

list insertFirst(int data,list ls)
{
	list temp;
	if(ls==NULL)
	{
		ls=create(data);
	}
	else
	{
		temp=create(data);
		temp->next=ls;
		ls=temp;
		return ls;
	}
}

list reverse(list ls)
{
	if(ls==NULL)
	{

		return 0;
	}
	else
	{
		reverse(ls->next);

		printf("%d ",ls->data);

	}
}

list count(list ls)
{
	if(ls==NULL)
	{
		return 0;
	}
	else
	{
		list temp;
		temp=ls;
		int length=0;
		while(temp!=NULL)
		{
			length++;
			temp=temp->next;
		}
		printf("Count: %d",length);
	}
}

void print(list ls)
{
	if(ls==NULL)
	{
		printf("NULL");
		return;
	}
	else
	{
		printf("%d-->",ls->data);
		print(ls->next);
	}
}


int main()
{

	list akshay=create(10);

	insert(20,akshay);
	insert(30,akshay);
	print(akshay);
	printf("\n");
	printf("Insert First : ");
	akshay=insertFirst(100,akshay);
	print(akshay);
	printf("\n");
	printf("reverse list : ");
	reverse(akshay);
	printf("\n");
	count(akshay);
	printf("\n");


}

