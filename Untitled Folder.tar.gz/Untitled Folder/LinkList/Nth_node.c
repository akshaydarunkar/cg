#include<stdio.h>
#include<stdlib.h>

struct Node
{
	struct Node *next;
	int data;
};

void push(struct Node** node, int data)
{
struct Node* newnode=(struct Node *)malloc(sizeof(struct Node));

newnode->data=data;
newnode->next=*node;
*node=newnode;

}

int Nth(struct Node* head,int data)
{
	struct Node* current=head;
	int count=0;
	
	while(current!=NULL)
	{
	if(count==data)
		return(current->data);
	count++;
	current=current->next;
	}
}

		
int main()
{
	struct Node* head=NULL;
	
	push(&head,1);
	push(&head,4);
	push(&head,1);
	push(&head,12);
	push(&head,5);
	
	printf("element index :%d",Nth(head,3));
}

