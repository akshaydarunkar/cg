#include<stdio.h>
#include<stdlib.h>

struct node
{
	int data;
	struct node* next;
};

void push(struct node** node ,int data)
{
	struct node* newnode=(struct node*)malloc(sizeof(struct node));
	struct node* temp;
	
	newnode->data=data;
	newnode->next=*node;
	*node=newnode;
}
void middel(struct node* node)
{
	struct node *fast=node;
	struct node *slow=node;
	
	if(node!=NULL)
	{
		while(fast!=NULL && fast->next!=NULL)
		{
			fast=fast->next->next;
			slow=slow->next;
		}
		printf("midel element: %d ",slow->data);
	}
}
void print(struct node* node)
{
	while(node!=NULL)
	{
	printf("%d-> ",node->data);
	node=node->next;
	}
	printf("NULL\n");
}

int main()
{
	struct node* node=NULL;
	
	for(int i=11;i>0;i--)
	{
	push(&node,i);
	print(node);
	middel(node);
	}
return 0;
}


	
	
