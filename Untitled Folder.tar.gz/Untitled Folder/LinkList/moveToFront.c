#include<stdio.h>
#include<stdlib.h>

struct Node
{
	int data;
	struct Node *next;
};

void push(struct Node** node,int data)
	{	
	struct Node* newnode=(struct Node*)malloc(sizeof(struct Node));

	newnode->data=data;
	newnode->next=*node;
	*node=newnode;
	}

void moveTostart(struct Node **node)
{
	if((*node)==NULL || (*node)->next==NULL)
		return;
	struct Node *secLast=NULL;
	struct Node *last=*node;
	
	while(last->next!=NULL)
	{
		secLast=last;
		last=last->next;
	}
	secLast->next=NULL;
	last->next=*node;
	*node=last;
}

void print(struct Node *node)
{
	while(node!=NULL)
	{
		printf("%d",node->data);
		node=node->next;
	}
}

int main()
{
	struct Node *node=NULL;
	
	push(&node,1);
	push(&node,2);
	push(&node,3);
	push(&node,4);
	push(&node,5);
	printf("previus\n");
	print(node);
	moveTostart(&node);
	printf("now\n");
	print(node);
	return 0;
}
