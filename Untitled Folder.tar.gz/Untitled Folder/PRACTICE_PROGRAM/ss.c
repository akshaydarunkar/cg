#include <stdio.h>

int main()
{
	int arr[20],i,largest,size;
	printf("how many element:");
	scanf("%d",&size);
	printf("\n enter %d elment :",size);
	for(i=0;i<size;i++)
		scanf("%d",&arr[i]);

	largest=arr[0];
	for(int i=1;i<size;i++)
	{
		if(largest>arr[i])
			largest=arr[i];
	}
	printf ("MAX=%d",largest);
	return 0;	
}
