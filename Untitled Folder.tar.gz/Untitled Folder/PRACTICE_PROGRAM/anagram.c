#include <math.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <assert.h>
#include <limits.h>
#include <stdbool.h>

int makingAnagrams(char* s1/*[]*/, char* s2/*[]*/){
	int first[26]={0},second[26]={0},temp=0;   
    for(int i=0;s1[i]!='\0';i++)
    {
        first[s1[i]-'a']++;
        
    }
    for(int i=0;s2[i]!='\0';i++)
    {
        second[s2[i]-'a']++;
        
    }
    for(int i=0;i<26;i++)
 { 			
           temp+=abs(first[i]-second[i]);
  }
    return temp;
}

int main() {
    char* s1 = (char *)malloc(512000 * sizeof(char));
    scanf("%s", s1);
    char* s2 = (char *)malloc(512000 * sizeof(char));
    scanf("%s", s2);
    int result = makingAnagrams(s1, s2);
    printf("%d\n", result);
    return 0;
}

