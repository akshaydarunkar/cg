#include<stdio.h>

int main()
{

int no = 3,a=1234;
float num = 123.45;
printf("%*d\n",no,a);

