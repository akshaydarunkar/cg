#include<stdio.h>
#include<stdlib.h>

int main()
{
        int arr[]={12,4,78,90,45,23};
        int n=sizeof(arr)/sizeof(arr[0]);
//      int result=LIS(arr,n);
        printf("%d ",LIS(arr,n));
        return 0;
}

int LIS(int arr[],int n)
{
        int i,j;
        int iLIS[n+1];
        for(i=0;i<n;i++)
                iLIS[i]=1;
        for(i=1;i<n;i++)
        {
                for(j=0;j<i;j++)
                {
                        if((arr[i] > arr[j]) && (iLIS[i] < iLIS[j]+1))
                        {
                                iLIS[i]=iLIS[j]+1;
                        }
                }
        }
        int max=0;
        for(i=0;i<n;i++)
        {
                if(max<iLIS[i])
                {
                        max=iLIS[i];
                }
        }
        return max;
}

