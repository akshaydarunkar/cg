#include<stdio.h>
#include<stdlib.h>

int main()
{
	int arr[]={-2,-3,4,-1,-2,1,5,-3};
	int n = sizeof(arr)/sizeof(arr[1]);

	int max=maxsubArray(arr,n);
	printf("MAX:%d",max);
	return 0;
}

int maxsubArray(int arr[],int n)
{
	int start=0,end=0;
	for(int i=0;i<n;i++)
	{
		end+=arr[i];

		if(start<end)
			start=end;

		if(end<0)
			end=0;

	}
	return start;
}

