lude<stdio.h>
#include<string.h>

void main()
{
        char str[]="akshayakshayakshay";
        int arr[26]={0};
        int i,k=0;
        char uniqString[100];

        for(i=0;i<strlen(str);i++)
        {
                arr[str[i]-97]+=1;

        }

        for(i=0;i<26;i++){
                if(arr[i] != 0){
                        uniqString[k++]=65+i;
                }
        }

        for(i=0;i<strlen(str);i++)
        {

                //printf("%c=%d\n",str[i],arr[str[i]-97]);


                printf("%c",uniqString[i]);
        }
        
}



