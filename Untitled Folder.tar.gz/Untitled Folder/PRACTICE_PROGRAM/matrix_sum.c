#include<stdio.h>

int main()
{

	int m,n,a[10][20],sum=0;
	printf("enter n*m matrix");
	scanf("%d%d",&m,&n);

	for(int i=0;i<m;i++)
	{
		for(int j=0;j<n;j++)
		{
			scanf("%d",&a[i][j]);
	//		printf("%d \n",a[i][j]*a[i][j]);
		//	sum+=a[i][j];
		}
	}
	
	for(int i=0;i<m;i++)
	{
		for(int j=0;j<n;j++)
		{
	//		scanf("%d",&a[i][j]);
			printf("%d ",a[i][j]*a[i][j]);
		//	sum+=a[i][j];
		}
	printf("\n");
	}
	
//	printf("%d",sum);
//	printf("%d",sum);
	return 0;
}


