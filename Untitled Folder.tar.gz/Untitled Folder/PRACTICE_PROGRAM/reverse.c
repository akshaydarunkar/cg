#include<stdio.h>

int main()
{

	char arr[]="akshay";
	reverse(arr);
	return 0;
}

void reverse(char *str)
{
	if(*str)
	{
		reverse(str+1);
		printf("%c",*str);
	}

}


