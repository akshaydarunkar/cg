#include<stdio.h>
#include<string.h>

int main()
{
	char str[]="akshefgh\n";
	findOut(str);
	int n=findOut(str);
	printf("%d",n);
	return 0;
}

int findOut(char *str)
{
	int result=0;
	for(int i=0;i<strlen(str);i++)
		if(i==(str[i]-'a') || i==(str[i]-'A'))
			result++;
		return result;				
}
