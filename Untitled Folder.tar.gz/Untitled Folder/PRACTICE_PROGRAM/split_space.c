#include<stdio.h>
#include<string.h>

/*int main()
{
	char str[]="this is a string";
	char *c;

	printf("STRING:%s\n",str);

	c=strtok(str," ");
	
	while(c!=NULL)
	{
		printf("%s\n",c);
		c=strtok(NULL," ");
	}
	return 0;
}
*/

int main()
{
 	FILE *fp;
        char *c;
	char p;
       fp=fopen("t.txt","r");
	p=fgetc(fp);
	
        c=strtok(p," ");
        
        while(c!=EOF)
        {
                printf("%s\n",c);
                c=strtok(NULL," ");
        }
	fclose(fp);
        return 0;
}

