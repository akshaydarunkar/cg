function validate_email() 
{ 
    var emailReg = /^([\w-\.]+@([\w-]+\.)+[\w-]{2,4})?$/; 
    var emailval=document.getElementById("email").value; 
    var emaillen=Number(emailval.length); 
    if(emaillen===0) 
    { 
    document.getElementById("email_msg").innerHTML="Email id should not be empty "; 
    } 
    else if(!emailval.match(emailReg)) 
    { 
    document.getElementById("email_msg").innerHTML="Invalid Email Address\n"; 
    } 
    else 
    { 
    document.getElementById("email_msg").innerHTML=""; 
    } 
     
}
