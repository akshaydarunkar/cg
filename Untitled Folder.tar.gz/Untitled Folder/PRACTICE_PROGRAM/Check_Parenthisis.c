#include<stdio.h>
#include<string.h>
#include<stdlib.h>

int top=-1;
char stack[100];

void push(char);
void pop();
void find_top();

void main()
{
	int i;
	char a[100];
	printf("\nEnter Expression\n");
	scanf("%c",&a);

	for(i=0;a[i]!='\0';i++)
	{
		if(a[i]=='(')
		{
			push(a[i]);
		}
		else if(a[i]==')')
		{
			pop();
		}
	}
	find_top();
}

	void push(char a)
	{
		stack[top]=a;
		top++;
	}

	void pop()
	{
		if(top==-1)
		{
			printf("\nExpression Invalid\n");
			exit(0);
		}
		else
		{
			top--;	
		}
	}
	void find_top()
	{
		if(top==-1)

			printf("\n Expression valid\n");

		else
			printf("\n Expression Invalid\n");

	}





