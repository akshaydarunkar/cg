#include<stdio.h>
#include<string.h>
void main()
{
	char str[500];
	int i,total=0,alp[26]={0};

	printf("enter string\n");
	scanf("%s",str);

	for(i=0;str[i]!='\0';i++)
	{
		if('a'<=str[i] && str[i]<='z')
		{
			total+=!alp[str[i]-'a'];
			alp[str[i]-'a']=1;
		}

		else if('A'<=str[i] && str[i]<='Z')
		{
			total+=!alp[str[i]-'A'];
			alp[str[i]-'Z']=1;
		}
	}
	if(total==26)
	{
		printf("pangram");
	}
	else
	{
		printf("not pangram");
	}
}

