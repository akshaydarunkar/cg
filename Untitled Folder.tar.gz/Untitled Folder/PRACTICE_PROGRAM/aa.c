#include<stdio.h>
void f(void);
x=15108;

int main()
{
f();
printf("hhh:%d",x);
return 0;
}

