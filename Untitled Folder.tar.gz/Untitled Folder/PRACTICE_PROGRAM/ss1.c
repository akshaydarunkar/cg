#include <stdio.h>
 
int largest(int arr[], int n)
{
    int i;
    
    int max = arr[0];
 
   for (i = 1; i < n; i++)
        if (arr[i] > max)
            max = arr[i];
 
    return max;
}
 
int main()
{
    int arr[] = {10, 324, 45, 90, 9808};
    int n = sizeof(arr)/sizeof(arr[0]);

	printf("n=%d\n",n);
	printf("arr=%d\n",sizeof(arr));
	printf("arr[0]=%d\n",sizeof(arr[1]));

    printf("Largest in given array is %d\n", largest(arr, n));
    return 0;
}
