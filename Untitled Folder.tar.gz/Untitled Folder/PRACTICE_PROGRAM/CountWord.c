#include<stdio.h>
#include<string.h>

int main()
{
	char str[]="abc";
	int len=strlen(str);
	printf("COuntWords: %d\n",Countword(str,len));
	return 0;
}

int Countword(char str[],int len)
{

	int count=1;

	if(len==1)
		return count;
	if(str[0]==str[1])
		count *=1;
	else
		count *=2;


	for(int i=1;i<len-1;i++)
	{
		if(str[i]==str[i-1] && str[i]==str[i+1])
			count *=1;
		else if(str[i]==str[i-1] ||	
			str[i]==str[i+1] ||
			str[i-1]==str[i+1])
				count *=2;
		else
			count *=3;
	}
	if(str[len-1]==str[len-2])
		count *=1;
	else
		count *=2;
	return count;
}


