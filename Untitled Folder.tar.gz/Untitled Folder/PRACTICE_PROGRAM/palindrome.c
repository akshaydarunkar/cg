#include<stdio.h>
#include<string.h>

int main()
{

	char str[10];
	int i,length;
	int flag=0;

	printf("enter string:");
	scanf("%s",str);

	length=strlen(str);

	for(i=0;i<length;i++)
	{
		if(str[i] != str[length-i-1])
		{
		flag=1;
		}
	}
	 
	if(flag){
	
		printf("%s not palindrome\n",str);
	}
	else{
		printf("%s palindrom\n",str);
	}
	return 0;
}

