#include<stdio.h>
#include<assert.h>
int main()
{

	int x=7;
	x=2;
	assert(x==5);
		return 0;
}

