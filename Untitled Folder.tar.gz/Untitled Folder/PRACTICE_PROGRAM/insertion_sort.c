#include<stdio.h>
#include<stdlib.h>

int main()
{
	int arr[]={5,2,6,7,1,2};
	int n = sizeof(arr)/sizeof(arr[0]);

	insertion(arr,n);
	//	print(arr,n);
	return 0;
}

int insertion(int arr[],int n)
{

	int i,j,temp;
	for(i=1;i<n;i++)
	{
		temp=arr[i];
		j=i-1;
		while(j>=0 && arr[j]>temp)
		{
			arr[j+1]=arr[j];
			j=j-1;
		}

		arr[j+1]=temp;
	}
	for(i=0;i<n;i++)
	{
		printf("AA:%d\n",arr[i]);
	}
}

int print(int arr[],int n)
{
	int i;
	for(i=0;i<n;i++)
		printf("%d ",arr[i]);
	printf("\n");
}

