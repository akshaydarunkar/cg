#include<stdio.h>
#include<string.h>
int main()
{

char str[]="Geeks for Geeks";
char *c=strtok(str," ");
while(c!=NULL)
{
printf("%s\n",c);
c=strtok(NULL," ");
}
return 0;
}

 

