#include<stdio.h>
#include<stdlib.h>

int main()
{
	int arr[]={12,4,78,99,45,23};
	int n=sizeof(arr)/sizeof(arr[0]);
	printf("%d \n",Bitonic(arr,n));
	return 0;
}

int Bitonic(int arr[],int n)
{

	int inc[n];
	int dec[n];
	int i,max;

	inc[0]=1;
	dec[n-1]=1;

	for(i=1;i<n;i++)
                inc[i]=(arr[i]>=arr[i-1]) ? inc[i-1]+1:1;	
	

	for(i=n-2;i>=0;i--)
		dec[i]=(arr[i]>=arr[i+1]) ? dec[i+1]+1:1;

	for(i=0;i<n;i++)
	max=inc[0]+dec[0]-1;
	for(i=0;i<n;i++)
		if(max<inc[i]+dec[i]-1)
			max=inc[i]+dec[i]-1;
	return max;

}

