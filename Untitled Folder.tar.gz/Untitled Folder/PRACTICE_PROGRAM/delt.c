#include <stdio.h>
#include <stdlib.h>
struct node {
	int data ;
	struct node * next ;
} * head = NULL ;
void push ( int val )
{
	struct node * newnode = ( struct node * ) malloc ( sizeof ( struct node ) ) ;
	newnode -> data = val ;
	newnode -> next = NULL ;
	struct node * ptr = head ;
	if ( ptr == NULL )
		head = newnode ;
	else
	{
		while ( ptr -> next )
			ptr = ptr -> next ;
		ptr -> next = newnode ;
	}
}
void print ()
{
	struct node * itr ;
	itr = head ;
	while ( itr )
	{
		printf ( " %d " , itr -> data ) ;
		itr = itr -> next ;
	}
}
void delNode ( struct node * del )
{
	struct node * temp ;
	del -> data = del -> next -> data ;
	temp = del -> next ;
	del -> next = temp -> next ;
	free ( temp ) ;
}
int main ()
{
	push ( 2 ) ;
	push ( 3 ) ;
	push ( 1 ) ;
	push ( 8 ) ;
	push ( 7 ) ;
	print () ;
	delNode( head -> next -> next) ;
	printf ( " \n ") ;
	print () ;
	return 0 ;
}

