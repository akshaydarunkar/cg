#include<stdio.h>

int main()
{
	int i,limit,sml=1;

	printf("enter smilly:\n");
	scanf("%d",&limit);

	for(i=0;i<limit;i++)
	{
		printf("%c \n",sml);
	}
}

