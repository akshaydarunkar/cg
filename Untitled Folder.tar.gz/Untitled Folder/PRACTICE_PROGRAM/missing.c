#include<stdio.h>

int main()
{
	int arr[]={1,6,2,8,4,3,7};
	int n = sizeof(arr)/sizeof(arr[1]);

	int miss = missing(arr,n);
	printf("%d ",miss);
	return 0;
}

int missing(int arr[],int n)
{

	int total,i;

	total=(n+1)*(n+2)/2;
	for(i=0;i<n;i++)
		total-=arr[i];
	return total;
}

