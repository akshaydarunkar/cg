#include<stdio.h>
#include<string.h>

int main()
{

	int i,j;
	char s[20];
	printf("\n enter string\n");
	scanf("%c",&s);

	for(i=0;s[i];i++)
	{
		for(j=0;j<i;j++)
		
			printf("%c",s[j]);
		
		printf("\n");
	}
	return 0;
}

