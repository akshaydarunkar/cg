#include<stdio.h>
int main()
{
int no1=0,no2=0,no3=0;
scanf("%2d %2d\n",&no1,&no2);
printf("%d %d %d\n",no1,no2,no3);
return 0;
}

