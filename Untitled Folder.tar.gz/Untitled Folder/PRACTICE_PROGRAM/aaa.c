#include<stdio.h>
int main()
{
printf("jay maharashtra");
}


