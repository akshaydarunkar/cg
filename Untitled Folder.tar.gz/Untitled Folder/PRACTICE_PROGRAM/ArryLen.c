#include<stdio.h>
#include<stdlib.h>
#include<string.h>
int main()
{

	int arr[]={1,2,9,4,5,6};
	int max=0;

	int n=sizeof(arr)/sizeof(arr[0]);
	//printf("%d",n);
	max=arr[0];
	for(int i=1;i<n;i++)
	{
		if(max<n)
			max=arr[i];
	}
	printf("%d",max);

	return 0;
}

