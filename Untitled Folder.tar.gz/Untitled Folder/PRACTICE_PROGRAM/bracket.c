#include<stdio.h>
#include<stdlib.h>

int main()
{
	int  i=0;
	char str[50];

	printf("enter String: ");
	scanf("%s",str);
//	gets(str);
	int count=0;

	while(str[i]!='\0')
	{
		if(str[i]=='}')
			count--;
		if(str[i]=='{')
			count++;
		if(count<0)
		{
			printf("\nInnvalid\n");
			break;
		}
		i++;
	}
	if(count==0)
		printf("\nvalid\n");
	else
		printf("Invalid\n");
	return 0;

}

