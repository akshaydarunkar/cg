#include<stdio.h>

int main()
{
	for(5;2;2)
		printf("hello\n");
			break;
	return 0;
}

