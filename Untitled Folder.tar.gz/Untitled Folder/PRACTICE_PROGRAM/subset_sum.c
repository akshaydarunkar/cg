#include<stdio.h>
#include<stdlib.h>

bool issubset(int arr[],int n,int sum)
{
	if(sum==0)
		return true;
	if(n==0 && sum!=0)
		return false;

	if(arr[n-1]>sum)
		return issubset(arr,n-1,sum);

	return issubset(arr,n-1,sum) || issubset(arr,n-1,sum-arr[n-1]);
}

int main()
{
	int arr[]={3,34,4,12,5,2};
	int n= sizeof(arr)/sizeof(arr[0]);
	int sum;
	printf("enter value of sum:\n ");
	scanf("%d",&sum);
	if(issubset(arr,n,sum)==true)
		printf("subset with given sum\n");
	else
		printf("not subset with given sum\n");
	return 0;
}

