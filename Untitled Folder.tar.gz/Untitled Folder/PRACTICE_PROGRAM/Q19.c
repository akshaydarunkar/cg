#include<stdio.h>
int fun(int (*fp)(const char*,...),char *ptr)
{

	return fp(ptr);
}
int main()
{
	int no = 0;
	char *ptr1 = "akshay";
	no = fun(printf,ptr1);
	printf("return value in %d",no);

	return 0;
}

