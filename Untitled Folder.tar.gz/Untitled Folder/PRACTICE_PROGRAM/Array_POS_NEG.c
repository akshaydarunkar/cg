#include<stdio.h>
#include<stdlib.h>

int main()
{
	int arr[]={-12,11,-13,-5,6,-7};
	int n=sizeof(arr)/sizeof(arr[0]);

	PosNeg(arr,n);
	print(arr,n);

	return 0;
}

void PosNeg(int arr[],int n)
{

	int key,i,j;

	for(i=1;i<n;i++)
	{
		key=arr[i];
		if(key>0)
			continue;
		j=i-1;
		while(j>=0 && arr[j]>0)
		{
			arr[j+1]=arr[j];
			j=j-1;
		}
		arr[j+1]=key;
	}
}
void print(int arr[],int n)
{
	int i;
	for(i=0;i<n;i++)
		printf("%d ",arr[i]);
	printf("\n");
}



