#include <stdio.h>
#include <string.h>
#include <ctype.h>

int main (void)
{
  char str[] = "akshay popat darunkar";

  char f_name[6], m_name[6], l_name[8];
  strcpy(f_name, strtok(str, " "));
  strcpy(m_name, strtok(NULL, " "));
  strcpy(l_name, strtok(NULL, " "));
 

printf("last name: %c%s\n", toupper(l_name[0]), l_name + 1);
printf("first name: %c%s\n", toupper(f_name[0]), f_name + 1);

printf("middel name: %c%s\n", toupper(m_name[0]), m_name + 1);

return 0;
}

