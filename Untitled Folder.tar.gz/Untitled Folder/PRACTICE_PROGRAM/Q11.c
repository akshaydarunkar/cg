#include<stdio.h>
int main()
{
int no1,no2,no3,no;
no=scanf("%d%d%d\n",&no1,&no2,&no3);
printf("%d\n",no);
return 0;
}

