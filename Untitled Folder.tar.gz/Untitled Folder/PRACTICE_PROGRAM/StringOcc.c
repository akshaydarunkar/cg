#include<stdio.h>
#include<string.h>

int Occurance(char *str)
{
	int i,count[]={0};
	
	int len=strlen(str);

	for(int i=0;i<len;i++)
	{
		count[str[i]]++;
	}
	int max=-1;
	char result;	
	
	for(int i=0;i<len;i++)
	{
		if(max < count[str[i]])
		{
			max=count[str[i]];
			result=str[i];
		}
	}
	return result;
}

int main()
{
	char str[]="aksshay";
	Occurance(str);
	printf("%c",Occurance(str));
	return 0;
}

