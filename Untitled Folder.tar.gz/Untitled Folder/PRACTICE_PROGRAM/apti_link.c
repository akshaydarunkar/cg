https://onlinetyari.com/question-bank/question-15-__-27-27-39-39-%E2%80%A6-i34033.html

http://www.java-samples.com/showtutorial.php?tutorialid=595


http://www.m4maths.com/5235-Look-at-this-series-15-27-27-39-39-What-number-should-fill-the-blank-A-51-B-39-C.html

http://www.sanfoundry.com/python-problems-solutions/


http://careerride.com/question-3-Aptitude

https://mcalglobal.com/socialresume/user/take-quiz.htm?catid=java&nameid=39085728-c912-467f-b6e6-54dcf1cdb807
