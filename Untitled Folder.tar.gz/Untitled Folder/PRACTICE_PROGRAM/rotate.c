#include<stdio.h>
#include<stdlib.h>
int main()
{
	int arr[]={1,2,3,4,5,6,7};
	rotate(arr,5,7);
	printArry(arr,7);
	getchar();
	return 0;
}

void rotate(int arr[],int d,int n)
{
	int i;
	for(i=0;i<d;i++)
		rotateonebyone(arr,n);

}	
void rotateonebyone(int arr[],int n)
{
	int temp,i;
	temp=arr[0];
	for(i=0;i<n-1;i++)
		arr[i]=arr[i+1];
		arr[i]=temp;
	
}
void printArry(int arr[],int size)
	{
		int i;
		for(i=0;i<size;i++)

			printf("%d ",arr[i]);

	}

