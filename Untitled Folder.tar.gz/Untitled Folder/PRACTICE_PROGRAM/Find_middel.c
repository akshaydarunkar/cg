#include <stdio.h>
#include <stdlib.h>
struct node {
	int data ;
	struct node * next ;
} * head = NULL ;
void push ( int val )
{
	struct node * newnode = ( struct node * ) malloc ( sizeof ( struct node ) ) ;
	newnode -> data = val ;
	newnode -> next = NULL ;
	struct node * ptr = head ;
	if ( ptr == NULL )
		head = newnode ;
	else
	{
		while ( ptr -> next )
			ptr = ptr -> next ;
		ptr -> next = newnode ;
	}
}
void print ()
{
	struct node * itr ;
	itr = head ;
	while ( itr )
	{
		printf ( " %d \n" , itr -> data ) ;
		itr = itr -> next ;
	}
}
int middle ()
{
	struct node * slow , * fast ;
	slow = head ;
	fast = head ;
	if ( head )
	{
		while ( slow -> next && fast -> next )
		{
			slow = slow -> next ;
			fast = fast -> next -> next ;
		}
	}
	return slow -> data ;
}
int main ()
{
	push ( 2 ) ;
	push ( 3 ) ;
	push ( 1 ) ;
	push ( 8 ) ;
	push ( 7 ) ;
	push ( 5 ) ;
	push ( 4 ) ;
	print () ;
	printf ( " The middle element is %d \n" , middle () ) ;
	printf ( " \n ") ;
//	print () ;
	return 0 ;
}
