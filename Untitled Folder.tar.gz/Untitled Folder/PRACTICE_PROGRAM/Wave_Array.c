#include<stdio.h>
#include<stdlib.h>

void main()
{

	int arr[]={12,9,5,73,5,7,4};
	int n = sizeof(arr)/sizeof(arr[0]);
	void wave(arr,n);
	for(int i=0;i<n;i++)
		printf("\n%d\n",arr[i]);

}

void wave(int arr[],int n)
{

	unsigned sort(arr,arr+n);

	for(int i=0;i<n-1;i+=2)
		swap(&arr[i],&arr[i+1]);
}

void swap(int *x,int *y)
{
	int temp=*x;
	*x=*y;
	*y=temp;
}

