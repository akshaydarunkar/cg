#include<stdio.h>
int main()
{

printf("%X%x%ci%x",11,10,'s',12);
}

