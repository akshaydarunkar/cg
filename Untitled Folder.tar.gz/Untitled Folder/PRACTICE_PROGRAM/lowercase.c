#include<stdio.h>

int main()
{

	char ch;
	printf("Enter string\n");
	scanf("%c",&ch);
	ch=ch+92;
	
	printf("STRING:%c\n",ch);
}

