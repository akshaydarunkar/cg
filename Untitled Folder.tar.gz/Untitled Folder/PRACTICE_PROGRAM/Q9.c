#include<stdio.h>
int main()
{

printf("%c","akshay harshal\n"[4]);

char arr[]="akshay harshal";
printf("%c\n",arr[4]);
printf(5+"akshay harshal\n");

printf("%d\n",printf("akshay harshal\n"));

printf("akshay" "harshal");
printf("\n");
printf("akshay","harshal");
return 0;
}

