#include<stdio.h>
#include<string.h>

int Count(char a[],char b[],int m,int n)
{

	if((m==0 && n==0) || n==0)
		return 1;

	if(m==0)
		return 0;

	if(a[m-1]==b[n-1])
		return Count(a,b,m-1,n-1)+
			Count(a,b,m-1,n);
	else
		return Count(a,b,m-1,n);
}	


int main()
{

	char arr[20],arr1[20];
	printf("enter 1st String:\n");
	scanf("%s",arr);	
	printf("enter 2st String:\n");
	scanf("%s",arr1);	

	//char a[]="DaruDanDksar";
//	char b[]="a";

	int len=strlen(arr);
	int len1=strlen(arr1);

	printf("Count: %d \n",Count(arr,arr1,len,len1));
	return 0;
}

