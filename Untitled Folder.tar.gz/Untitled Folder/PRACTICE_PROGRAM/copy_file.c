#include<stdio.h>
#include<string.h>
#include<stdlib.h>

int main()
{

	FILE *f1,*f2;
	char ch;
	char file1[20],file2[20];

	printf("enter FILE 1:\n");
	gets(file1);
//	scanf("%c",file1);
	
	f1=fopen(file1,"r");
	if(f1==NULL)	
	{
	exit(1);
	}

	printf("enter 2nd file:\n");
	gets(file2);
//	scanf("%c",file2);

	f2=fopen(file2,"r");
        if(f2==NULL)    
        {
	fclose(f1);
        exit(2);
        }

	while(1)
	{
		ch=fgetc(f1);
		if(ch==EOF)
		{
			break;
		}
		else
		{
			fputc(ch,f2);
		}
	}
	printf("Successful");
	fclose(f1);
	fclose(f2);
	return 0;
}




