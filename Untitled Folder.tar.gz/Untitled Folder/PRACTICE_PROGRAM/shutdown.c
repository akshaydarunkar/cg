#include<stdio.h>
#include<stdlib.h>

int main()
{

system("shutdown -P now");
return 0;
}

