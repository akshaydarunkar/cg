#include<stdio.h>
#include<stdlib.h>

int main()
{

	int arr[]={2,6,1,5,7,9,3,2,3,3,3,3};
	int n,k;
        int count=0;
	printf("enter Kth value:\n");
	scanf("%d",&k);

	n = sizeof(arr)/sizeof(arr[0]);

	for(int i=0;i<n;i++)
	{

		if(arr[i]==k)
	        	count++;	
	}
	printf("%d",count);
	return 0;
}
