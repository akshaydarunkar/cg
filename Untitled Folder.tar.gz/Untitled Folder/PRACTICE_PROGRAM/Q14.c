#include<stdio.h>
int main()
{
int no;
printf("Plsease enter value");
scanf("%3d\n",&no);
printf("%d",no);
return 0;
}

