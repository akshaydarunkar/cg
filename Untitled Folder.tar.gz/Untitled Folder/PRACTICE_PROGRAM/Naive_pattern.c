#include<stdio.h>
#include<string.h>
#include<stdlib.h>

int search(char *ptr,char *txt)
{

	int i,j;
	int m=strlen(ptr);
	int n=strlen(txt);

	for(i=0;i<n-m;i++)
	{
	   for(j=0;j<m;j++)
	      if(txt[i+j]!=ptr[j])
		break;

	      if(j==m)
		printf("pattern found at index %d \n",i);
	}
}


int main()
{
        char txt[] = "AABAACAADAABAAABAA";
        char pat[] = "AABA";
        search(pat,txt);
        return 0;
}

