#include<stdio.h>
#include<string.h>

int main()
{

	char temp,str[]="akshay";
	int i=0,j=0;

	j=strlen(str)-1;
//	printf("%d",j);
	while(i<j)
	{
		temp=str[i];
		str[i]=str[j];
		str[j]=temp;
		i++;
		j--;
	}
	printf("reverse:%s\n",str);
	return 0;
}

