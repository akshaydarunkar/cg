#include<stdio.h>

int main()
{

	char str[]="134";
	printf("%d",even(str));
	return 0;

}

int even(char str[])
{
	int len = strlen(str);
	int count=0;
	for(int i=0;i<len;i++)
	{
		int temp=str[i]-'0';
		if(temp%2==0)
			count+=(i+1);
	}
	return count;
}


