#include<stdio.h>
int main()
{
int no1 = 0, no2 = 0;
char str[2];
no2=sprintf(str,"%d %s\n",no1,"Akashay");
printf("%d\n",no2);
no2 = printf("%s\n",str);
printf("%d",no2);
return 0;
}


