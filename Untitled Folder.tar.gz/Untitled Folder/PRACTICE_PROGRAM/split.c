#include<stdio.h>

int main()
{

FILE *fp;
char arr[100],c;

fp=fopen("t.txt","r");
c=fgetc(fp);
while(c!=EOF)
{
printf("%c \n",c);
c=fgetc(fp);
}
fclose(fp);
return 0;
}

