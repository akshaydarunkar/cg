#include<stdio.h>

int main()
{
int n;
printf("enter no\n");
scanf("%d",&n);


binaryPattern(n);
return 0;
}

void binaryPattern(int n)
{

int row,col;

for(row=0;row<n;row++)
{
	for(col=0;col<=row;col++)
	{
		if(((row+col)%2)==0)
		
			printf("0");
		else
			printf("1");
		
		printf("\t");
	}
			printf("\n");
}
}


