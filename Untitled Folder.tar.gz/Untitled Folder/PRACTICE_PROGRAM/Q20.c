#include<stdio.h>
int main()
{
printf("\\nMarvellous\\r");
printf("\n%%%%%%%%%%");
return 0;

}
