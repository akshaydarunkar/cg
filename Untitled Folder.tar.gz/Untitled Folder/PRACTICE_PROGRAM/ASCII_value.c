#include<stdio.h>
#include<stdlib.h>

int main()
{

	int i;
	char ch;

	for(i=0;i<255;i++)
	{
		ch=i;
		printf("%d -> %c\t",i,ch);
	}
}

