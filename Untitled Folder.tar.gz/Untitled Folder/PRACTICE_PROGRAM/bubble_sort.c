#include<stdio.h>
#include<stdlib.h>

int bubble(int arr[],int n)
{

	int i,j;
	for(i=0;i<n-1;i++)
		for(j=0;j<n-i-1;j++)

			if (arr[j]>arr[j+1])
				swap(&arr[j],&arr[j+1]);
			for(i=0;i<n;i++)
			{
			printf("%d ",arr[i]);
			}
}
int swap(int *x,int *y)
{
	int temp=*x;
	*x=*y;
	*y=temp;
}

int print(int arr[],int n)
{
	int i;
	for(i=0;i<n;i++)
	printf("%d ",arr[i]);
	//printf("\n");
}
int main()
{
	int arr[]={4,2,6,5,9,8};
	int n = sizeof(arr)/sizeof(arr[1]);

	bubble(arr,n);
	//print(arr,n);
	return 0;
}

