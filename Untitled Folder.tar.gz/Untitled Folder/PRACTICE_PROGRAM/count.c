#include<stdio.h>
#include<string.h>
 
// Function that return count of the given character
// in the string
int count(char *str, char c)
{
    // Count variable
    int res = 0;
 	int len = strlen(str);
    for (int i=0; i<len;i++)
 
        // checking character in string
        if (str[i] == c)
            res++;
 
    return res;
}
 
// Driver code
int main()
{
    char str[]= "geeksforgeeks";
    char c = 'e';
    int result = count(str, c);
    printf("%d\n", count(str, c));
    return 0;
}
