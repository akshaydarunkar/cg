#include<stdio.h>
#include<stdlib.h>

int main()
{
	char ch;
	printf("DO u want to shutdown LAPY (Y/N):");
	scanf("%c",&ch);

	if(ch=='y' || ch=='Y')
	{
		system("shutdown -p now");
	}
	return 0;
}

