#include<stdio.h>
#include<stdlib.h>
#define R 3
#define C 3

int spiral(int m,int n,int arr[R][C])
{

	int i,k=0,l=0;

	while(k<m && l<n)
	{
		for(i=l;i<n;++i)
		{
			printf("%d ",arr[k][i]);
		}
		k++;
	
		for(i=k;i<m;++i)
		{
			printf("%d ",arr[i][n-1]);
		}
		n--;
	
		if(k<m)
		{
			for(i=n-1;i>=l;--i)
			{
			printf("%d ",arr[m-1][i]);
			}
			m--;
		}

		if(l<n)
		{
			for(i=m-1;i>=k;--i)		
			{
			printf("%d ",arr[i][l]);
			}
			l++;
		}
	}
}


int main()
{
int arr[R][C]={{1,2,3},
             {4,5,6},
              {7,8,9}};


        spiral(R,C,arr);
        return 0;
}
