#include<stdio.h>
int main()
{
int a=10,b=20;
//printf("%d %d",a,b);
printf("%*d %*d",a,30,b,5);
return 0;
}
