#include<stdio.h>
int main()
{
int x=3,no=0;
no=printf("akshay:%d",x);
return 0;
}

