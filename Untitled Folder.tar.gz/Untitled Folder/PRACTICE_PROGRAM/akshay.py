def aa(*p):
	a,b = p
	print "a:%r,b:%r"%(a,b)

aa("akshay","darunkar")

