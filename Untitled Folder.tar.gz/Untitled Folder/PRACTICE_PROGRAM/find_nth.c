#include <stdio.h>
#include <stdlib.h>
struct node {
	int data ;
	struct node * next ;
} * head = NULL ;
void push ( int val )
{
	struct node * newnode = ( struct node * ) malloc ( sizeof ( struct node ) ) ;
	newnode -> data = val ;
	newnode -> next = NULL ;
	struct node * ptr = head ;
	if ( ptr == NULL )
		head = newnode ;
	else
	{
		while ( ptr -> next )
			ptr = ptr -> next ;
		ptr -> next = newnode ;
	}
}
void print ()
{
	struct node * itr ;
	itr = head ;
	while ( itr )
	{
		printf ( " %d \n" , itr -> data ) ;
		itr = itr -> next ;
	}
}
void find ( int idx )
{
	struct node * ptr = head ;
	printf ( " \n At position %d , " , idx ) ;
	while( -- idx )
	{
		if ( !ptr )
			break ;
		ptr = ptr -> next ;
	}
	printf ( "Found %d ." , ptr -> data ) ;
}

int main ()
{
	push ( 3 ) ;
	push ( 4 ) ;
	push ( 2 ) ;
	push ( 1 ) ;
	push ( 5 ) ;
	print() ;
	find ( 2 ) ;
	return 0 ;
}
