#include<stdio.h>

int main()
{

int arr[]={14,26,38,4,455};

int max,i,n;

n=sizeof(arr)/sizeof(arr[1]);
max=arr[0];
for(i=0;i<n;i++)
{
if(max>arr[i])
	max=arr[i];
}
printf("MAX=%d",max);
return 0;
}
