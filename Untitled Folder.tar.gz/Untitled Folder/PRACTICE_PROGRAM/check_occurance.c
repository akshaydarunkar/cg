#include<stdio.h>
#include<string.h>

void main()
{
	char str[]="akshayakshayakshay";
	int arr[26]={0};
	int i;
	

	for(i=0;i<strlen(str);i++)
	{
		arr[str[i]-97]+=1;
		//printf("%d",arr[i]);
		
	}

	for(i=0;i<strlen(str);i++)
	{
		//arr[str[i]-97]+=1;
		printf("%c=%d\n",str[i],arr[str[i]-97]);
		
	}
	
}





