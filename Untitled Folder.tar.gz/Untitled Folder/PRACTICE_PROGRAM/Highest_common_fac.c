#include<stdio.h>

int hcf(int a, int b)
{
	while(a!=b)
	{
		if(a>b)
		{
			return hcf(a-b,b);
		}
		else
		{
			return hcf(a,b-a);
		}
		return a;
	}
}

int main()
{

	int a,b,result;

	printf("enter a & b value: ");
	scanf("%d%d",&a,&b);

	result=hcf(a,b);
	printf("DIff:%d\n",result);
	return 0;
}

