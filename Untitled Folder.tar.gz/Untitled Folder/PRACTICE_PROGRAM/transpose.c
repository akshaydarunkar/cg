#include<stdio.h>

int main()
{

	int A[10][10],B[10][10],i,j,n,m;

	printf("Enter value row and colom:\n");
	scanf("%d%d",&n,&m);
	printf("enter matrix element:\n");
	for(i=0;i<n;i++)
	{
		for(j=0;j<m;j++)
		{
			scanf("%d",&A[i][j]);
		}
	}
	for(i=0;i<n;i++)
	{
		for(j=0;j<m;j++)
		{
			B[i][j]=A[j][i];
		}
	}
	printf("Transpose matrix ->\n");
	for(i=0;i<n;i++)
	{
		for(j=0;j<m;j++)
		{
			printf("%d ",B[i][j]);
		}
		printf("\n");

	}
	printf("\n");
	return 0;
}
