#include<stdio.h>
#include<stdlib.h>

int main()
{
	int arr[]={8,6,1,3,12,0,9,2};
	int n=sizeof(arr)/sizeof(arr[0]);

	alternate(arr,n);
	return 0;
}

void alternate(int arr[],int n)
{
	sort(arr,arr+n);
	int i=0,j=n-1;
	while(i<j)
	{
		printf(" ",j--);
		printf(" ",i++);
	}
	if(n%2!=0)
		printf(" ",arr[i]);
}

