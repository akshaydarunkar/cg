//#include<bits/stdc++.h>
//using namespace std;
#include<stdio.h>
#include<string.h>
// Return the maximum length prefix which is
// subsequence.
int maxPrefix(char s[], char t[])
{
    int count = 0;
 	int i;
    // Iterating string T.
    for ( i = 0; i < strlen(t); i++)
    {
        // If end of string S.
        if (count == strlen(s))
            break;
 
        // If character match, increment counter.
        if (t[i] == s[count])
            count++;
    }
 	printf("%c\n",s[i]);
	
 	printf("%c\n",s[i+1]);
 	printf("%c\n",s[i-1]);
 	printf("%c\n",t[i]);
 	printf("%c\n",t[i-1]);
	
	
	
	
    return count;
}
 
// Driven Program
int main()
{
    char S[] = "akshay";
    char T[] = "ahy";
    printf("%d\n",maxPrefix(S,T));
    //cout << maxPrefix(S, T) << endl;
 
    return 0;
}
