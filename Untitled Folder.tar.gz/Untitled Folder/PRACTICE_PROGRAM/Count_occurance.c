#include<stdio.h>
#include<string.h>

int main()
{
        char str[]="geeksforgeeks";
        char c;
        printf("%s\n",str);
        printf("which character retutn of given string:");
        scanf("%c",&c);
        int result=count(str,c);
        printf("%d\n",count(str,c));
        return 0;
}

int count(char *str,char c)
{
        int res=0;
        int len = strlen(str);

        for(int i=0;i<len;i++)

                if(str[i] == c)
                        res++;
        return res;

}

