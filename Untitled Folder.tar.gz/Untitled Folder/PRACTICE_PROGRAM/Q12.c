#include<stdio.h>
int main()
{
int no1,no2,no3,no;
printf("Plsease enter 3 numbers");
no=scanf("%d%*d%d\n",&no1,&no2,&no3);
printf("%d\n",no);
printf("%d\n%d\n%d\n",no1,no2,no3);
return 0;
}


