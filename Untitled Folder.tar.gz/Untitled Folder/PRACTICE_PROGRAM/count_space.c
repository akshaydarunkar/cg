#include <stdio.h>
#include <string.h>
 
int main()
{
   char a[100];
   int length;
   printf("Enter a string: ");
   scanf("%s",a);

   length = strlen(a);
   printf("Length: = %d\n",length);
   return 0;
}
