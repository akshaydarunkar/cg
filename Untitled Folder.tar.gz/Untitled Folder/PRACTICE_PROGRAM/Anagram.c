#include <stdio.h>

int check_anagram(char [], char []);

int main()
{
	char a[100], b[100];
	int flag;

	printf("Enter first string\n");
	gets(a);

	printf("Enter second string\n");
	gets(b);

	flag = check_anagram(a, b);

	if (flag == 1)
		printf("\"%s\" and \"%s\" are anagrams.\n", a, b);
	else
		printf("\"%s\" and \"%s\" are not anagrams.\n", a, b);

	return 0;
}

int check_anagram(char a[], char b[])
{
	int first[26] = {0}, second[26] = {0}, i = 0;

	while (a[i] != '\0')
	{
		first[a[i]-'a']++;
		i++;
	}

	i = 0;

	while (b[i] != '\0')
	{
		second[b[i]-'a']++;
		i++;
	}

	for (i = 0; i < 26; i++)
	{
		if (first[i] != second[i])
			return 0;
	}

	return 1;
}


