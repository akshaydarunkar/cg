#include<stdio.h>
int main()
{
int no=0;
no=printf(":%d",printf("B:%d",printf("C:%d",printf("Demo"))));

printf("\nTotal count %d\n",no);
return 0;
}

