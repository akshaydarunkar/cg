#include<stdio.h>
#include<string.h>
int main()
{
	int arr[10],n,i;
	int sum=0;
	printf("how many elemnt\n");
	scanf("%d",&n);
	printf("enter arry element\n");
	for(i=0;i<n;i++)
	{
		scanf("%d",&arr[i]);
		
	//	printf("hello");
		
	}
//	int len = strlen(arr);
	
	printf("leg:%d\n",n);

//	printf("%d\n",add(arr,len));
//	return 0;


//	int add(int arr[],int n)
//	{

	for(int i=0;i<n;i++)

		sum=sum+arr[i];
	printf("%d\n",sum);
	return 0;

}
