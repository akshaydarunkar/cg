#include<stdio.h>
#include<string.h>
#include<stdlib.h>
int main()
{

	char a[]="1010",b[]="101";

	printf("Result:%c",Binary(a,b));
	return 0;
}
void Binary(char a[],char b[])
{
	char result=" ";
	int s=0;

	int i = strlen(a)-1;
	int j = strlen(b)-1;

	while(i>=0 || j>=0 || s==1)
	{
		s+=((i>=0) ? a[i]-'0': 0);
		s+=((j>=0) ? b[j]-'0': 0);


	    result=(s % 2 +'0')+result;
		s=s/2;
		i--;
		j--;
	}
	return result;
}

