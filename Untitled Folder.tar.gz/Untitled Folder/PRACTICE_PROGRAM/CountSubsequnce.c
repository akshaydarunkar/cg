#include<stdio.h>
#include<string.h>

int main()
{

	char str[]="abc";

	printf("%d\n",CountSubsequnce(str));
	return 0;
}

int CountSubsequnce(char str[])
{

	int result=0;
	int n=strlen(str);
	for(int i=0;i<n;i++)

		for(int j=i;j<n;j++)
			if(str[i]==str[j])
				result ++;
	return result;
}


