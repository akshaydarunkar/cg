#include<stdio.h>
int fun()
{
return printf("Exit from fun")+printf("second")*2;
}

int main()
{
printf("Return value %d\n",fun());
return 0;
}

