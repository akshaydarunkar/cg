#include<stdio.h>

int main()
{

	int arr[]={1,2,3,4,5,68};
	int n=6;
	int i;
	int f=arr[0];
	int s=arr[0];

	for(i=0;i<n;i++)
	{
		if(f<arr[i])
		{
			s=f;
			f=arr[i];
		}
		else if(s<arr[i])
		{
			s=arr[i];
		}
	}		
		printf("\nFirstLargest:%d \n",f);
		printf("\nSecondLargest:%d \n",s);
		printf("\nSum:%d \n",f+s);
	
	return 0;
}

