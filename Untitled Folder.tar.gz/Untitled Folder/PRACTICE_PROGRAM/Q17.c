#include<stdio.h>
int main()
{
int no=0;
no=printf("Enter number :%d",scanf("%d",&no));

printf("\nTotal count %d\n",no);
return 0;
}

