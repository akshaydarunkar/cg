#include<stdio.h>
#include<string.h>
void copy(char[],char[],int);

int main()
{
	char str1[]="akshay";
	char str2[20];
	int i;

	copy(str1,str2,0);

	printf("string1:%s\n",str1);
	printf("string2:%s\n",str2);
	return 0;
}

void copy(char str1[],char str2[],int i)
{

	str2[i]=str1[i];
	if(str1[i]=='\0')
	
		return 0;
	copy(str1,str2,i+1);
	
}



