public class Hello
{
	public static void main(String args[])
	{
	int a=10,b=20,c;
	c=a+b;
		System.out.print("Addition:"+c);
	}
}

