public class sumofdigit
{
	public static void main(String args[])
	{
		int n = Integer.parseInt(args[0]);

		int x,sum=0;

		while(n>0)
		{
			x=n%10;
			sum+=x;
			n/=10;
		}
		System.out.println("sumofdigit:"+sum);
	}
}
