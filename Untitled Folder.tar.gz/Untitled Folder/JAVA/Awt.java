import java.awt.*;
import javax.swing.*;
public class Awt
{
	public static void main(String args[])
	{

		JFrame f1=new JFrame("my frame");
		JPanel p1=new JPanel();
		JLabel l1=new JLabel("username:");
		JLabel l2=new JLabel("Password:");
		JTextField t1=new JTextField(20);
		JTextField t2=new JTextField(20);

		p1.add(l1);
		p1.add(t1);
		p1.add(l2);
		p1.add(t2);
		f1.add(p1);
			
		f1.setSize(350,100);
		f1.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		f1.setVisible(true);
	}
}

