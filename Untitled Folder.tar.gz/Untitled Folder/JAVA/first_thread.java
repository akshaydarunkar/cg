public class first_thread
{
	public static void main(String args[])
	{
		Thread t=Thread.currentThread();
		System.out.println("First thread after creation:"+t);

		t.setName("akshay");	
		System.out.println("First thread after creation:"+t);
	}
}

