import java.util.Collections.*;
import java.util.LinkedList.*;
import java.io.*;
import java.util.*;


public class union_list_collection
{
	static BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
	
	public static void main(String args[])throws IOException
	{
		LinkedList l1 = new LinkedList();
		LinkedList l2 = new LinkedList();
		LinkedList l3 = new LinkedList();
		
		System.out.println("Enter the how many element in first list:");
		int n1=Integer.parseInt(br.readLine());
		System.out.println("enter the element first list:");
		
		for(int i=1;i<=n1;i++)
		{
			System.out.println("enter element:"+i+":");
			String element=br.readLine();
			l1.add(element);
		}
		
		System.out.println("Enter the how many element in second list:");
                int n2=Integer.parseInt(br.readLine());
                System.out.println("enter the element second list:");

                for(int i=1;i<=n2;i++)
                {
                        System.out.println("enter element:"+i+":");
                        String element=br.readLine();
                        l2.add(element);
                }

		Collections.sort(l1);
		Collections.sort(l2);

		System.out.println("First List:"+l1);
		System.out.println("second List:"+l2);

		for(int i=0;i<l1.size();i++)
			l3.add(l1.get(i));
			
		for(int i=0;i<l2.size();i++)
			if(!l1.contains(l2.get(i)))
				l3.add(l2.get(i));
		System.out.println("Union:"+l3);
		
		
	}
}
		

		
