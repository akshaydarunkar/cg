// Java program to demonstrate get and set pixel
// values of an image
import java.io.File;
import java.io.IOException;
import java.awt.image.BufferedImage;
import javax.imageio.ImageIO;

public class image11
{
	public static void main(String args[])throws IOException
	{
		BufferedImage img = null;
		File f = null;
		try
		{
			f = new File("akshay.jpg");
			img = ImageIO.read(f);
		}
		catch(IOException e)
		{
			System.out.println(e);
		}
		int width = img.getWidth();
		int height = img.getHeight();
		int p = img.getRGB(0,0);

		int a = (p>>24) & 0xff;
		int r = (p>>16) & 0xff;
		int g = (p>>8) & 0xff;
		int a = p & 0xff;

		a = 255;
		r = 100;
		g = 150;
		b = 200;

		p = (a<<24) | (r<<16) | (g<<8) | b;
		img.setRGB(0, 0, p);

		try
		{
			f = new File("akshay.jpg");
			ImageIO.write(img, "jpg", f);
		}
		catch(IOException e)
		{
			System.out.println(e);
		}
	}
}

