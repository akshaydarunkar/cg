import java.io.*;
import java.util.*;
import java.util.Collections.*;
import java.util.ArrayList.*;

public class ArryList_collection
{
	public static void main(String args[])throws IOException
	{
		String str;
		try
		{
			BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
			System.out.println("Enter the how many no of String:");
			
			ArrayList arr=new ArrayList();
			int n=Integer.parseInt(br.readLine());
		
			for(int i=0;i<n;i++)
			{
				System.out.println("Enter String: ");
				str=br.readLine();
				arr.add(str);
			}
				
				System.out.println("before reverse: "+arr);
				Collections.reverse(arr);	
				System.out.println("after reverse:  "+arr);
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
}
