import java.io.*;

public class Reverse
{
	public static void main(String[] args)throws IOException
	{
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));

		System.out.println("Enter String:");

		String str=br.readLine();

		String arr[]=str.split("");

		int count =arr.length;

		System.out.println("Number of element:"+count);

		for(int i=count;i>0;i--)
		{
			System.out.print(""+arr[i-1]);
		}
	}
}
