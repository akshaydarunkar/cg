class example
{
	int x=10;
	public static int y;
	
	public void set()
	{
	System.out.println("X:"+x);
	}
	
	public static void static_set()
	{
	//y=4;
	System.out.println("Y:"+y);
	}
	static class test
	{
	public static String country="PUCSD";
	}
}
	public class Static_fun
	{
	public static void main(String[] args) 
	{
	example ex=new example();
	ex.set();
	example.y=100;
	example.static_set();
	System.out.println(example.test.country);
	}
	}
