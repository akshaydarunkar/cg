public class Asending
{
	public static void main(String args[])
	{
		int a = Integer.parseInt(args[0]);
		int b = Integer.parseInt(args[1]);
		int c = Integer.parseInt(args[2]);

		boolean x = (a<b && b<c)||(a>c && b>c);
		System.out.println(x);
	}
}






