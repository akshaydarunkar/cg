import java.io.*;
import java.util.Collections.*;
import java.util.LinkedList.*;
import java.util.*;

public class LinkedList_Reverse_Collection
{
	public static void main(String args[]) 
	{
		LinkedList l=new LinkedList();
		
		l.add("akshay");
		l.add("rahul");
		l.add("sagar");
		l.add("sandy");
		l.add("harshal");
		
		System.out.println("before string:"+l);
		Collections.sort(l);	
		System.out.println("after reverse  string:"+l);
	}
}




		
