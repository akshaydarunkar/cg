public class wraper
{
public static void main(String[] args)
{
	Integer i1=Integer.valueof("123");
	Double d1=Double.valueof("3.12");
}
}

