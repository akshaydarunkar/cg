class LinkedList
{
	Node head;
	class Node
	{
		int data;
		Node next;
		Node(int d){ data=d; next=null;}
	}
public void push(int data)
{
	Node node = new Node(data);
	node.next=head;
	head=node;
}

public void insertAfter(Node pos,int data)
{
	if(pos==null)
	{
	System.out.println("Not NULL");
	}
	Node node=new Node(data);

	node.next=pos.next;
	pos.next=node;
}
public int getcount()
{
	Node node=head;
	int i=0;
	while(node!=null)
	{
	i++;
	node=node.next;
	}
	return i;
}	

public void reverse()
{
	Node prev=null;
	Node next=null;
	Node current=head;
	
	while(current!=null)
	{
	next=current.next;
	current.next=prev;
	prev=current;
	current=next;
	}
	head=prev;
}
	
public void display()
{
	Node node=head;
	while(node!=null)
	{
		System.out.print(node.data+" ");
		node=node.next;
	}
}

public static void main(String[] args)
{
	LinkedList ls = new LinkedList();

	ls.push(1);
	ls.push(2);
	ls.push(3);
	ls.insertAfter(ls.head.next,50);
	System.out.print("Created Linkedlist:\n ");	
	ls.display();
	System.out.println("Length Linkedlist: "+ls.getcount());
	ls.reverse();		
//	System.out.println("Reverse Linkedlist: "+ls.reverse());
	ls.display();
	
}

}
