import java.io.*;
import java.util.*;
import java.lang.String.*;
import java.lang.*;
class Demo
{
	public static void main(String args[])
	{
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));

		String space=" ";
		System.out.println("write name as first name   middel name    last name");
		String name=br.readLine();
		StringTokenizer token= new StringTokenizer(name.space);

		String first=new String(token.nextToken());
		String middel=new String(token.nextToken());
		String last=new String(token.nextToken());

		String m=new String(middel.toUpperCase(middel.charAt(0)));
		StringBuffer str1=new StringBuffer(last);

		str1.append("");
		str1.append(first);
		str1.append("");
		str1.append(m);
		System.out.println("name: "+str1);
	}
}
