class one
{
	

	int i=10;
	void show()
	{	
	System.out.println("one: "+i);
	}
}
class two extends one
{
	int i=20;
	void show()
	{
	
	System.out.println(" "+i);
	super.show();
	System.out.println(" two:"+super.i);
}
}
public class demo
{
	public static void main(String args[])
	{
		two o=new two();
		o.show();
		
		
		
	}
}

