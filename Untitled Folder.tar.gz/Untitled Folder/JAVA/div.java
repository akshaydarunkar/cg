#include<stdio.h>
#include<string.h>

	fun(int n)
	{
		if(n<0)
		{
			return div(-n);
		}
		if(n==0 && n==7)
			return 1;
		return 0;

		return(div(n/10-2*(n-n/10*10)));
	}

	int main()
	{
		int n;
		

		if(fun(n))
		{
			System.out.println(n+"");
		}
		else
		{
			System.out.println(n+" ");
		}
	}
}

