public class Box
{
	private int height,width,length;
	
	public void setdimention(int h,int w,int l)
	{
	height=h;
	width=w;
	length=l;
	}
	public void show()
	{
	System.out.println("length:"+length);
	System.out.println("height:"+height);
	System.out.println("width:"+width);
	}
}
class example
{
public static void main(String[] args)
{
Box b1=new Box();

b1.setdimention(10,12,15);
b1.show();
}
}	
	
	
