import java.io.*;

public class Replace
{
	public static void main(String args[])
	{
		File file=new File("t.txt");
		int ch,n;
		n=Integer.parseInt(args[0]);

		StringBuffer content=new StringBuffer("");

		FileInputStream f=null;

		try
		{
			f=new FileInputStream(file);
			for(int i=0;(ch=f.read())!=-1;i++)
			{
				if(i==n)
					content.append((char)ch);
			}
			f.close();
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		System.out.println(content.toString());
	}
}

