class Basic_Function
{

public static void main(String akshay[])
{
	
	StringBuffer str= new StringBuffer("Have String");
	String s1 = "     Hello akshay    ";
	String s2 = "Darunkar akshay ";
	String s3 = " TO TO";
	String s4 = "by by";

	System.out.println(s1);
	System.out.println(s1.trim());
	System.out.println(s2.substring(3,5));
	System.out.println(s2.concat(" pucsd"));
	System.out.println(s3.toLowerCase());
	System.out.println(s2.replace("a","@"));
	System.out.println(s4.toUpperCase());
	System.out.println(s2.length());	
	System.out.println(s3.equals(s3));
	System.out.println(str.append(s3));
	
	
	
}
}

