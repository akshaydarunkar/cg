class Node
{
	int data;
	Node left,right;

	Node(int d)
	{
		data=d;
		left=right=null;
	}
}
class Binarytree
{
	Node root;

	Binarytree()
	{
		root=null;
	}
	int hight()
	{
		return hight(root);
	}
	int hight(Node node)
	{
		if(node==null)
		{
			return 0;
		}
		else
			return hight(node.left)+1+
				hight(node.right);
	}
	boolean leaf(Node node)
	{
		if(node==null)
			return false;
		if(node.left==null && node.right==null)
			return true;
		return false;
	}
	int leftSum(Node node)
	{
		int res=0;
		if(node!=null)
		{
			if(leaf(node.right))
				res+=node.right.data;
			else
				res+=leftSum(node.right);
		res+=leftSum(node.left);
		}
		return res;
	}
	int max(Node node)
	{
		if(node==null)
			return 0;
		
		int res=node.data;
		int l=max(node.left);
		int r=max(node.right);
		
		if(res<l)
			res=l;
		if(res<r)
			res=r;
		return res;
	}
	boolean fullyTree(Node node)
	{
		if(node==null)
			return true;
		if(node.left==null && node.right==null)
			return true;
		if((node.left!=null) && (node.right!=null))
			return (fullyTree(node.left) && fullyTree(node.right));
		return false;
	}

		
	public void inorder(Node node)
	{
		if(node==null)
		{
			return;
		}
		inorder(node.left);
		System.out.print(node.data+" ");
		inorder(node.right);
	}
	public void preorder(Node node)
	{
		if(node==null)
		{
			return;
		}
		System.out.print(node.data+" ");
		preorder(node.left);
		preorder(node.right);
	}
	public void postorder(Node node)
	{
		if(node==null)
		{
			return;
		}
		postorder(node.left);
		postorder(node.right);
		System.out.print(node.data+" ");
	}
	void inorder()
	{
		inorder(root);
	}
	void preorder()
	{
		preorder(root);
	}
	void postorder()
	{
		postorder(root);
	}

	public static void main(String args[])
	{
		Binarytree tree = new Binarytree();
		tree.root=new Node(1);
		tree.root.left=new Node(2);
		tree.root.right=new Node(3);
		tree.root.left.left=new Node(4);
		tree.root.left.right=new Node(5);
		tree.root.left.left.right=new Node(10);
		System.out.println("inorder");
		tree.inorder();
		System.out.println("\npreorder");
		tree.preorder();
		System.out.println("\npostorder");
		tree.postorder();
		
		System.out.println("\n");

		System.out.println("\nhight = "+tree.hight());
		System.out.println("\nmax = "+tree.max(tree.root));
		System.out.println("\nleaf = "+tree.leaf(tree.root));
	
		if(tree.fullyTree(tree.root))
			System.out.print("Fully\n");
		else
			System.out.print("\nNot Fully");
		System.out.println("\nleftSum:"+tree.leftSum(tree.root));
		
	}
}

