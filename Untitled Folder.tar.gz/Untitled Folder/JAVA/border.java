import java.awt.*;
import java.awt.event.*;
class border extends Frame
{
	Button b1,b2,b3,b4,b5;
	border()
	{
		b1=new Button("NORTH");
		b2=new Button("SOUTH");
		b3=new Button("WEST");
		b4=new Button("EAST");
		b5=new Button("CENTER");

		setSize(200,200);
		setLayout(new BorderLayout());
		add(b1,BorderLayout.NORTH);
		add(b2,BorderLayout.SOUTH);
		add(b3,BorderLayout.WEST);
		add(b4,BorderLayout.EAST);
		add(b5,BorderLayout.CENTER);
		setVisible(true);
	}
	public static void main(String args[])
	{
		new border();
	}
}











